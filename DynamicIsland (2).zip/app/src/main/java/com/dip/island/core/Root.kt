package com.dip.island.core

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Обёртка над `su`. Все вызовы блокирующие: звать из IO. */
object Root {
    const val LISTENER = "com.dip.island/com.dip.island.service.DipNotificationListener"

    fun run(cmd: String): Pair<Int, String> {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            val code = p.waitFor()
            code to (out + err).trim()
        } catch (e: Exception) {
            -1 to (e.message ?: "su недоступен")
        }
    }

    suspend fun runAsync(cmd: String): Pair<Int, String> = withContext(Dispatchers.IO) { run(cmd) }

    fun available(): Boolean {
        val r = run("id")
        return r.first == 0 && r.second.contains("uid=0")
    }

    /** Выдаёт все нужные разрешения без ручных шагов в настройках. Возвращает лог. */
    fun grantAll(ctx: Context): List<String> {
        val pkg = ctx.packageName
        val cmds = mutableListOf<String>()
        // Android 13+: sideload-приложениям закрыты listener и overlay, пока не снято ограничение
        cmds += "appops set $pkg ACCESS_RESTRICTED_SETTINGS allow"
        cmds += "appops set $pkg SYSTEM_ALERT_WINDOW allow"
        if (Build.VERSION.SDK_INT >= 33) cmds += "pm grant $pkg android.permission.POST_NOTIFICATIONS"
        cmds += "pm grant $pkg android.permission.READ_PHONE_STATE"
        cmds += "pm grant $pkg android.permission.ANSWER_PHONE_CALLS"
        if (Build.VERSION.SDK_INT >= 31) cmds += "pm grant $pkg android.permission.BLUETOOTH_CONNECT"
        cmds += "cmd notification allow_listener ${LISTENER}"
        cmds += "cmd deviceidle whitelist +$pkg"
        cmds += "appops set $pkg RUN_IN_BACKGROUND allow"
        cmds += "appops set $pkg RUN_ANY_IN_BACKGROUND allow"
        return cmds.map { c ->
            val r = run(c)
            (if (r.first == 0) "OK   " else "FAIL ") + c.removePrefix("pm grant $pkg ").take(70)
        }
    }

    fun key(code: Int) = run("input keyevent $code")
    fun answerCall() = key(5)
    fun endCall() = key(6)
    fun mediaPrev() = key(88)
    fun mediaNext() = key(87)
    fun mediaPlayPause() = key(85)

    /** Подавление системных heads-up баннеров, чтобы их заменял остров. */
    fun setHeadsUp(ctx: Context, hide: Boolean) {
        val sp = ctx.getSharedPreferences("dip_root", Context.MODE_PRIVATE)
        if (hide) {
            if (!sp.contains("heads_prev")) {
                val cur = run("settings get global heads_up_notifications_enabled").second.trim()
                sp.edit().putString("heads_prev", if (cur == "null" || cur.isEmpty()) "1" else cur).apply()
            }
            run("settings put global heads_up_notifications_enabled 0")
        } else {
            val prev = sp.getString("heads_prev", "1") ?: "1"
            run("settings put global heads_up_notifications_enabled $prev")
            sp.edit().remove("heads_prev").apply()
        }
    }
}
