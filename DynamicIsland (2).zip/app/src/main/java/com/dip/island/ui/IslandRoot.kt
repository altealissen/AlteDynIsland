package com.dip.island.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.ui.unit.dp
import com.dip.island.core.C
import com.dip.island.core.Env
import com.dip.island.core.Mode
import com.dip.island.core.Store
import com.dip.island.core.Target
import com.dip.island.core.Tok

private class Specs(val w: SpringSpec<Float>, val h: SpringSpec<Float>)

private fun specsFor(from: Mode, to: Mode): Specs = when {
    to == Mode.EXPANDED && from != Mode.EXPANDED -> Specs(Tok.EXPAND_W, Tok.EXPAND_H)
    from == Mode.EXPANDED && to != Mode.EXPANDED -> Specs(Tok.COLLAPSE_W, Tok.COLLAPSE_H)
    to == Mode.ALERT && from != Mode.ALERT -> Specs(Tok.ALERT_IN, Tok.ALERT_IN)
    from == Mode.ALERT && to != Mode.ALERT -> Specs(Tok.ALERT_OUT, Tok.ALERT_OUT)
    to == Mode.SPLIT && from != Mode.SPLIT -> Specs(Tok.SPLIT_ISLAND, Tok.SPLIT_ISLAND)
    from == Mode.SPLIT && to != Mode.SPLIT -> Specs(Tok.SPLIT_BACK, Tok.SPLIT_BACK)
    (from == Mode.HIDDEN || from == Mode.IDLE) && to == Mode.COMPACT -> Specs(Tok.APPEAR, Tok.APPEAR)
    from == Mode.COMPACT && (to == Mode.HIDDEN || to == Mode.IDLE) -> Specs(Tok.DISAPPEAR, Tok.DISAPPEAR)
    else -> Specs(Tok.ALERT_IN, Tok.ALERT_IN)
}

@Composable
fun IslandRoot() {
    val t by Store.target.collectAsState()
    val env by Store.env.collectAsState()
    val base = LocalViewConfiguration.current
    val lp = env.longPressMs
    val vc = remember(base, lp) {
        object : ViewConfiguration by base {
            override val longPressTimeoutMillis: Long get() = lp
        }
    }
    CompositionLocalProvider(LocalPt provides env.dpPerPt, LocalViewConfiguration provides vc) {
        IslandHost(t, env)
    }
}

@Composable
private fun IslandHost(t: Target, env: Env) {
    var last by remember { mutableStateOf(t) }
    SideEffect { if (t.mode != Mode.HIDDEN) last = t }
    val shown = if (t.mode == Mode.HIDDEN) last else t

    var prev by remember { mutableStateOf(t.mode) }
    val from = prev
    SideEffect { prev = t.mode }
    val sp = specsFor(from, t.mode)

    val l by animateFloatAsState(shown.left, sp.w, label = "left")
    val r by animateFloatAsState(shown.right, sp.w, label = "right")
    val h by animateFloatAsState(shown.h, sp.h, label = "h")
    val rad by animateFloatAsState(shown.radius, sp.h, label = "radius")
    val n by animateFloatAsState(shown.n, sp.w, label = "n")
    val isSplit = shown.mode == Mode.SPLIT && t.mode == Mode.SPLIT
    val bx by animateFloatAsState(if (isSplit) shown.bubbleCx else Tok.CAM_W / 2, Tok.BUBBLE_SPR, label = "bx")
    val bScale by animateFloatAsState(if (isSplit) 1f else 0f, Tok.BUBBLE_SPR, label = "bscale")
    val alpha by animateFloatAsState(
        if (t.mode == Mode.HIDDEN) 0f else 1f,
        tween(if (t.mode == Mode.HIDDEN) 120 else 30, if (t.mode == Mode.HIDDEN) 300 else 0), label = "alpha"
    )

    val cur by rememberUpdatedState(t)
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        if (pressed && (t.mode == Mode.COMPACT || t.mode == Mode.SPLIT)) Tok.LONG_PRESS_INFLATE else 1f,
        Tok.PRESS, label = "press"
    )

    val density = LocalDensity.current
    val topDp = (env.topPx / env.density).dp
    val wPt = (r - l).coerceAtLeast(1f)
    val cPt = (l + r) / 2f
    val radPx = with(density) { rad.pt().toPx() }
    val shape = IslandShape(radPx, n)

    Box(Modifier.fillMaxSize().graphicsLayer { this.alpha = alpha }) {
        // Основная капсула
        Box(
            Modifier.align(Alignment.TopCenter)
                .offset(x = cPt.pt(), y = topDp)
                .size(wPt.pt(), h.pt())
                .graphicsLayer {
                    scaleX = press; scaleY = press; transformOrigin = TransformOrigin(0.5f, 0f)
                }
                .clip(shape)
                .background(C.Black)
                .then(
                    if (env.keyline && t.mode == Mode.EXPANDED)
                        Modifier.border(0.5.dp, Color.White.copy(alpha = 0.14f), shape) else Modifier
                )
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            if (cur.mode == Mode.COMPACT || cur.mode == Mode.SPLIT) pressed = true
                            try { tryAwaitRelease() } finally { pressed = false }
                        },
                        onLongPress = {
                            if ((cur.mode == Mode.COMPACT || cur.mode == Mode.SPLIT) && cur.main != null) {
                                Store.expanded.value = true
                            }
                        },
                        onTap = {
                            val c = cur
                            if (c.mode == Mode.COMPACT || c.mode == Mode.SPLIT || c.mode == Mode.EXPANDED) {
                                c.main?.open?.invoke()
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    var acc = 0f
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = {
                            if (acc < -24.dp.toPx() && cur.mode == Mode.EXPANDED) Store.expanded.value = false
                        },
                        onDragCancel = { },
                        onVerticalDrag = { _, dy -> acc += dy }
                    )
                }
                .pointerInput(Unit) {
                    var acc = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = {
                            val m = cur.mode
                            if (kotlin.math.abs(acc) > 40.dp.toPx() && (m == Mode.COMPACT || m == Mode.SPLIT)) {
                                Store.cycle()
                            }
                        },
                        onDragCancel = { },
                        onHorizontalDrag = { _, dx -> acc += dx }
                    )
                }
        ) {
            IslandContent(shown)
        }

        // Отделённый пузырь (split)
        val bub = shown.bubble
        if (bub != null && bScale > 0.01f) {
            val src = remember { MutableInteractionSource() }
            Box(
                Modifier.align(Alignment.TopCenter)
                    .offset(x = bx.pt(), y = topDp)
                    .size(Tok.BUBBLE.pt(), Tok.CAM_H.pt())
                    .graphicsLayer { scaleX = bScale; scaleY = bScale }
                    .clip(CircleShape)
                    .background(C.Black)
                    .clickable(interactionSource = src, indication = null) { Store.select(bub.id) },
                contentAlignment = Alignment.Center
            ) { LeadIcon(bub) }
        }
    }
}

@Composable
private fun IslandContent(shown: Target) {
    val key = when (shown.mode) {
        Mode.EXPANDED -> "x:" + shown.main?.id
        Mode.ALERT -> "a:" + shown.alert?.id
        Mode.COMPACT, Mode.SPLIT -> "c:" + shown.main?.id
        else -> "i"
    }
    val snaps = remember { HashMap<String, Target>() }
    snaps[key] = shown
    AnimatedContent(
        targetState = key,
        modifier = Modifier.fillMaxSize(),
        transitionSpec = {
            fadeIn(tween(Tok.CONTENT_IN_MS, Tok.CONTENT_IN_DELAY)) togetherWith
                fadeOut(tween(Tok.CONTENT_OUT_MS, Tok.CONTENT_OUT_DELAY))
        },
        contentAlignment = Alignment.TopStart,
        label = "content"
    ) { k ->
        val tt = snaps[k] ?: shown
        val p by transition.animateFloat(
            transitionSpec = { tween(Tok.CONTENT_IN_MS, Tok.CONTENT_IN_DELAY) }, label = "appear"
        ) { st -> if (st == EnterExitState.PreEnter) 1f else 0f }
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer {
                    val s = 1f - (1f - Tok.CONTENT_SCALE) * p
                    scaleX = s; scaleY = s; transformOrigin = TransformOrigin.Center
                }
                .blur((Tok.CONTENT_BLUR * p).dp)
        ) {
            when (tt.mode) {
                Mode.EXPANDED -> tt.main?.let { ExpandedContent(it) }
                Mode.ALERT -> tt.alert?.let { AlertContent(it) }
                Mode.COMPACT, Mode.SPLIT -> CompactContent(tt)
                else -> Unit
            }
        }
    }
}
