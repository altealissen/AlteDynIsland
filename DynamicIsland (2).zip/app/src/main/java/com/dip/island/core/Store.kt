package com.dip.island.core

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/** Реестр активностей, очередь алертов и общее состояние UI. Все вызовы с главного потока. */
object Store {
    val items = MutableStateFlow<Map<String, IslandItem>>(emptyMap())
    val alert = MutableStateFlow<IslandAlert?>(null)
    val expanded = MutableStateFlow(false)
    val pinned = MutableStateFlow<String?>(null)
    val env = MutableStateFlow(Env())
    val target = MutableStateFlow(Target())
    val listenerConnected = MutableStateFlow(false)
    val serviceRunning = MutableStateFlow(false)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val queue = ArrayDeque<IslandAlert>()
    private var alertJob: Job? = null
    private var autoCollapse: Job? = null

    fun put(item: IslandItem) {
        val old = items.value[item.id]
        items.value = items.value + (item.id to item)
        // Входящий звонок раскрывает остров автоматически
        if (item.kind == Kind.CALL && item.incoming && old?.incoming != true) {
            expanded.value = true
        }
        // Уведомление показывается раскрытым и сворачивается само
        if (item.kind == Kind.NOTIF && old == null) {
            expanded.value = true
            autoCollapse?.cancel()
            autoCollapse = scope.launch {
                delay(Prefs.notifMs)
                if (items.value[item.id]?.kind == Kind.NOTIF) expanded.value = false
            }
        }
    }

    fun remove(id: String) {
        if (!items.value.containsKey(id)) return
        val removed = items.value[id]
        items.value = items.value - id
        if (pinned.value == id) pinned.value = null
        if (items.value.isEmpty() || (removed?.incoming == true)) expanded.value = false
    }

    fun removeWhere(pred: (IslandItem) -> Boolean) {
        items.value.values.filter(pred).forEach { remove(it.id) }
    }

    fun purge(now: Long) {
        removeWhere { it.expiresAt in 1..now }
    }

    fun clearAll() {
        items.value = emptyMap(); alert.value = null; expanded.value = false; pinned.value = null
        queue.clear()
    }

    fun alert(a: IslandAlert) {
        if (alert.value?.id == a.id) {
            alert.value = a
            return
        }
        queue.removeAll { it.id == a.id }
        queue.addLast(a)
        if (alertJob?.isActive == true) return
        alertJob = scope.launch {
            while (queue.isNotEmpty()) {
                val next = queue.removeFirst()
                alert.value = next
                delay(Prefs.alertMs)
                alert.value = null
                delay(380)
            }
        }
    }

    /** Переключение прикреплённой активности (тап по пузырю, свайп по острову). */
    fun cycle() {
        val order = Geo.order(items.value.values, pinned.value)
        if (order.size < 2) return
        pinned.value = order[1].id
    }

    fun select(id: String) {
        pinned.value = id
    }
}
