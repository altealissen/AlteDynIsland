package com.dip.island.service

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.dip.island.core.Glyph
import com.dip.island.core.IslandAlert
import com.dip.island.core.IslandItem
import com.dip.island.core.Kind
import com.dip.island.core.Prefs
import com.dip.island.core.Store

/** Системные события: зарядка, звук, авиарежим, DND, наушники, фонарик, микрофон. */
class SystemEvents(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private var lastLevel = -1
    private var lastPlugged = false
    private var lowShown = 100
    private var first = true
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!Prefs.srcSystem) return
            when (i.action) {
                Intent.ACTION_BATTERY_CHANGED -> onBattery(i)
                AudioManager.RINGER_MODE_CHANGED_ACTION -> onRinger()
                Intent.ACTION_AIRPLANE_MODE_CHANGED -> {
                    val on = i.getBooleanExtra("state", false)
                    Store.alert(
                        IslandAlert(
                            "airplane", if (on) "Авиарежим" else "Авиарежим выкл.", "", 0xFFFFFFFF,
                            Glyph.AIRPLANE, if (on) 0xFFFF9F0A else 0xFFFFFFFF
                        )
                    )
                }
                NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED -> {
                    val on = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
                    Store.alert(
                        IslandAlert(
                            "dnd", if (on) "Не беспокоить" else "Уведомления", "", 0xFFFFFFFF,
                            Glyph.MOON, if (on) 0xFF5E5CE6 else 0xFFFFFFFF
                        )
                    )
                }
                PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> {
                    val on = pm.isPowerSaveMode
                    Store.alert(
                        IslandAlert(
                            "saver", if (on) "Энергосбережение" else "Обычный режим", "", 0xFFFFFFFF,
                            Glyph.SAVER, if (on) 0xFFFFD60A else 0xFFFFFFFF
                        )
                    )
                }
                "android.intent.action.HEADSET_PLUG" -> {
                    if (i.getIntExtra("state", 0) == 1) {
                        Store.alert(IslandAlert("headset", "Наушники", "", 0xFFFFFFFF, Glyph.HEADPHONES))
                    }
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> onBluetooth(i, true)
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> onBluetooth(i, false)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun onBluetooth(i: Intent, connected: Boolean) {
        val dev: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        val name = try {
            dev?.name
        } catch (e: SecurityException) {
            null
        } ?: "Bluetooth"
        val short = if (name.length > 16) name.take(15) + "…" else name
        Store.alert(
            IslandAlert(
                "bt:" + (dev?.address ?: "x"), if (connected) short else "$short откл.", "", 0xFFFFFFFF,
                Glyph.HEADPHONES, if (connected) 0xFFFFFFFF else 0xFF8F8F90
            )
        )
    }

    private fun onBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        if (first) {
            first = false; lastLevel = pct; lastPlugged = plugged; return
        }
        if (plugged && !lastPlugged) {
            val full = pct >= 100
            Store.alert(
                IslandAlert(
                    "charge", if (full) "Заряжено" else "Зарядка", "$pct %",
                    if (full) 0xFF30D158 else 0xFF52FFA9, Glyph.BATTERY, 0xFF56FE36, pct
                )
            )
        } else if (plugged && pct != lastLevel && pct == 100) {
            Store.alert(IslandAlert("charge", "Заряжено", "100 %", 0xFF30D158, Glyph.BATTERY, 0xFF56FE36, 100))
        }
        if (!plugged && pct in 0..20 && lowShown > 20) {
            lowShown = pct
            Store.alert(
                IslandAlert("low", "Низкий заряд", "$pct %", 0xFFFF453A, Glyph.BATTERY, 0xFFFF453A, pct)
            )
        }
        if (!plugged && pct in 0..10 && lowShown > 10) {
            lowShown = pct
            Store.alert(
                IslandAlert("low", "Очень низкий заряд", "$pct %", 0xFFFF453A, Glyph.BATTERY, 0xFFFF453A, pct)
            )
        }
        if (pct > 25 || plugged) lowShown = 100
        lastLevel = pct; lastPlugged = plugged
    }

    private fun onRinger() {
        when (audio.ringerMode) {
            AudioManager.RINGER_MODE_SILENT ->
                Store.alert(IslandAlert("ringer", "Без звука", "", 0xFFFFFFFF, Glyph.BELL_OFF, 0xFFFF453A))
            AudioManager.RINGER_MODE_VIBRATE ->
                Store.alert(IslandAlert("ringer", "Вибрация", "", 0xFFFFFFFF, Glyph.BELL_OFF, 0xFFFFFFFF))
            else ->
                Store.alert(IslandAlert("ringer", "Звонок", "", 0xFFFFFFFF, Glyph.BELL, 0xFFFFFFFF))
        }
    }

    private val torchCb = object : CameraManager.TorchCallback() {
        private val seen = HashMap<String, Boolean>()
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            val prev = seen.put(cameraId, enabled)
            if (prev == null || prev == enabled || !Prefs.srcSystem) return
            Store.alert(
                IslandAlert(
                    "torch", if (enabled) "Фонарик" else "Фонарик выкл.", "", 0xFFFFFFFF,
                    Glyph.FLASH, if (enabled) 0xFFFFD60A else 0xFF8F8F90
                )
            )
        }
    }

    private val recCb = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
            if (!Prefs.srcPrivacy) return
            if (configs.isNullOrEmpty()) {
                Store.remove("ind:mic")
            } else if (!Store.items.value.containsKey("ind:mic")) {
                Store.put(
                    IslandItem(
                        id = "ind:mic", kind = Kind.RECORDING, pkg = ctx.packageName,
                        title = "Микрофон", subtitle = "Микрофон используется", accent = 0xFFFF9F0A
                    )
                )
            }
        }
    }

    fun register() {
        if (registered) return
        registered = true
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            addAction("android.intent.action.HEADSET_PLUG")
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else ctx.registerReceiver(receiver, f)
        try {
            (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager).registerTorchCallback(torchCb, main)
        } catch (e: Exception) {
        }
        try {
            audio.registerAudioRecordingCallback(recCb, main)
        } catch (e: Exception) {
        }
    }

    fun unregister() {
        if (!registered) return
        registered = false
        try { ctx.unregisterReceiver(receiver) } catch (e: Exception) { }
        try { (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager).unregisterTorchCallback(torchCb) } catch (e: Exception) { }
        try { audio.unregisterAudioRecordingCallback(recCb) } catch (e: Exception) { }
    }
}
