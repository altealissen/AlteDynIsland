package com.dip.island.core

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

object Prefs {
    private lateinit var sp: SharedPreferences
    val rev = MutableStateFlow(0)

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("dip", Context.MODE_PRIVATE)
        }
    }

    private fun bool(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun putBool(key: String, v: Boolean) {
        sp.edit().putBoolean(key, v).apply(); rev.value = rev.value + 1
    }

    private fun flt(key: String, def: Float) = sp.getFloat(key, def)
    private fun putFlt(key: String, v: Float) {
        sp.edit().putFloat(key, v).apply(); rev.value = rev.value + 1
    }

    private fun lng(key: String, def: Long) = sp.getLong(key, def)
    private fun putLng(key: String, v: Long) {
        sp.edit().putLong(key, v).apply(); rev.value = rev.value + 1
    }

    var enabled: Boolean
        get() = bool("enabled", true); set(v) = putBool("enabled", v)
    var showIdle: Boolean
        get() = bool("showIdle", false); set(v) = putBool("showIdle", v)
    var keyline: Boolean
        get() = bool("keyline", true); set(v) = putBool("keyline", v)
    var scale: Float
        get() = flt("scale", 1f); set(v) = putFlt("scale", v)
    var longPressMs: Long
        get() = lng("longPressMs", 350L); set(v) = putLng("longPressMs", v)
    var alertMs: Long
        get() = lng("alertMs", 3000L); set(v) = putLng("alertMs", v)
    var notifMs: Long
        get() = lng("notifMs", 5000L); set(v) = putLng("notifMs", v)

    // Источники
    var srcMedia: Boolean
        get() = bool("srcMedia", true); set(v) = putBool("srcMedia", v)
    var srcCalls: Boolean
        get() = bool("srcCalls", true); set(v) = putBool("srcCalls", v)
    var srcTimers: Boolean
        get() = bool("srcTimers", true); set(v) = putBool("srcTimers", v)
    var srcNav: Boolean
        get() = bool("srcNav", true); set(v) = putBool("srcNav", v)
    var srcNotifs: Boolean
        get() = bool("srcNotifs", true); set(v) = putBool("srcNotifs", v)
    var srcSystem: Boolean
        get() = bool("srcSystem", true); set(v) = putBool("srcSystem", v)
    var srcPrivacy: Boolean
        get() = bool("srcPrivacy", true); set(v) = putBool("srcPrivacy", v)

    // Root
    var rootActions: Boolean
        get() = bool("rootActions", true); set(v) = putBool("rootActions", v)
    var suppressHeadsUp: Boolean
        get() = bool("suppressHeadsUp", false); set(v) = putBool("suppressHeadsUp", v)
}
