package com.dip.island.ui

import android.content.Intent
import android.provider.Settings
import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import com.dip.island.core.Act
import com.dip.island.core.C
import com.dip.island.core.Glyph
import com.dip.island.core.IslandItem
import com.dip.island.core.Kind
import com.dip.island.core.Tok
import com.dip.island.core.Util

@Composable
private fun Modifier.at(x: Float, y: Float): Modifier = this.offset(x.pt(), y.pt())

@Composable
private fun CircleBtn(
    cx: Float, cy: Float, hitPt: Float, bg: Color?, onClick: () -> Unit, content: @Composable () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier.at(cx - hitPt / 2, cy - hitPt / 2).size(hitPt.pt())
            .clip(CircleShape)
            .then(if (bg != null) Modifier.background(bg) else Modifier)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

private fun IslandItem.act(vararg a: Act): (() -> Unit)? =
    actions.firstOrNull { it.act in a }?.run

@Composable
fun ExpandedContent(item: IslandItem) {
    when (item.kind) {
        Kind.MEDIA -> MediaExpanded(item)
        Kind.TIMER -> TimerExpanded(item)
        Kind.CALL -> CallExpanded(item)
        else -> CardExpanded(item)
    }
}

// --------------------------------------------------------------------- media (DIP_20 §8.1)

@Composable
private fun MediaExpanded(i: IslandItem) {
    val ctx = LocalContext.current
    val nowE by tickElapsed(250)
    val pos = if (i.playing) i.positionMs + ((nowE - i.stampElapsed) * i.speed).toLong() else i.positionMs
    val dur = i.durationMs
    val posC = if (dur > 0) pos.coerceIn(0L, dur) else pos.coerceAtLeast(0L)
    val frac = if (dur > 0) posC.toFloat() / dur else 0f

    Box(Modifier.fillMaxSize()) {
        BitmapBox(i.cover, 66f.pt(), 12.74f.pt(), modifier = Modifier.at(21.8f, 24.1f))
        PtText(i.title, 16.6f, C.White, FontWeight.SemiBold, Modifier.at(108.3f, 36.1f).width(200f.pt()))
        PtText(i.subtitle, 16.6f, C.Secondary, FontWeight.Normal, Modifier.at(108.3f, 57.4f).width(200f.pt()))
        Box(Modifier.at(319.6f, 38.05f)) {
            Equalizer(6, 2.7f, 4.72f, 2.4f, 22.5f, i.accent.color(), i.playing)
        }

        // Время и прогресс
        Box(Modifier.at(25.4f, 108.8f)) { PtText(Util.mmss(posC), 10.9f, C.TimeText, FontWeight.Medium, tnum = true) }
        Box(Modifier.at(289.5f, 108.8f).width(60f.pt()), contentAlignment = Alignment.CenterEnd) {
            PtText(if (dur > 0) "-" + Util.mmss(dur - posC) else "", 10.9f, C.TimeText, FontWeight.Medium, tnum = true)
        }
        Box(
            Modifier.at(57.5f, 112.7f).width(251.3f.pt()).height(5f.pt())
                .clip(RoundedCornerShape(50)).background(C.ProgTrack)
        ) {
            Box(Modifier.fillMaxSize().then(Modifier)) {
                Box(
                    Modifier.width((251.3f * frac).pt()).height(5f.pt())
                        .clip(RoundedCornerShape(50)).background(C.ProgFill)
                )
            }
        }

        // Кнопки: центры по x 45.4 / 116.9 / 187.9 / 258.5 / 330.0, y 157.8
        CircleBtn(45.4f, 157.8f, 52f, null, onClick = { i.open?.invoke() }) {
            BitmapBox(i.appIcon, 26f.pt(), 6.5f.pt())
        }
        CircleBtn(116.9f, 157.8f, 52f, null, onClick = { i.act(Act.PREV)?.invoke() }) {
            GlyphIcon(Glyph.PREV, 30f.pt(), C.White)
        }
        CircleBtn(187.9f, 157.8f, 52f, null, onClick = { i.act(Act.PLAY, Act.PAUSE)?.invoke() }) {
            GlyphIcon(if (i.playing) Glyph.PAUSE else Glyph.PLAY, 36f.pt(), C.White)
        }
        CircleBtn(258.5f, 157.8f, 52f, null, onClick = { i.act(Act.NEXT)?.invoke() }) {
            GlyphIcon(Glyph.NEXT, 30f.pt(), C.White)
        }
        CircleBtn(330.0f, 157.8f, 52f, null, onClick = {
            try {
                val action = if (android.os.Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_VOLUME
                else Settings.ACTION_SOUND_SETTINGS
                ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
            }
        }) { GlyphIcon(Glyph.SPEAKER, 26f.pt(), C.White) }
    }
}

// --------------------------------------------------------------------- timer (DIP_20 §8.2)

@Composable
private fun TimerExpanded(i: IslandItem) {
    Box(Modifier.fillMaxSize()) {
        CircleBtn(16.8f + 24.8f, 19.3f + 24.8f, 49.6f, C.BtnGray, onClick = {
            (i.act(Act.STOP) ?: i.open)?.invoke()
        }) { GlyphIcon(Glyph.CLOSE, 24f.pt(), C.White) }
        CircleBtn(75f + 24.8f, 19.3f + 24.8f, 49.6f, C.Timer.copy(alpha = 0.28f), onClick = {
            (i.act(Act.PAUSE, Act.OTHER) ?: i.open)?.invoke()
        }) { GlyphIcon(if (i.running) Glyph.PAUSE else Glyph.PLAY, 24f.pt(), C.Timer) }

        PtText(i.title, 15f, C.Timer, FontWeight.Medium, Modifier.at(176.1f, 12f).width(181.3f.pt()))
        Box(Modifier.at(176.1f, 27f).width(181.3f.pt()), contentAlignment = Alignment.CenterEnd) {
            ClockText(i, 35f, C.Timer)
        }
    }
}

// --------------------------------------------------------------------- call

@Composable
private fun CallExpanded(i: IslandItem) {
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.at(21.8f, 27f).size(50f.pt()).clip(CircleShape).background(C.BtnGray), Alignment.Center) {
            if (i.cover != null) BitmapBox(i.cover, 50f.pt(), 25f.pt())
            else PtText(i.title.take(1).uppercase(), 22f, C.White, FontWeight.SemiBold)
        }
        PtText(i.title, 16.6f, C.White, FontWeight.SemiBold, Modifier.at(84f, 30f).width(150f.pt()))
        Box(Modifier.at(84f, 54f)) {
            if (i.incoming) PtText(i.subtitle.ifEmpty { "Входящий вызов" }, 15f, C.Secondary, FontWeight.Normal)
            else ClockText(i, 15f, C.Green)
        }
        val end = i.act(Act.DECLINE, Act.HANGUP)
        if (i.incoming) {
            CircleBtn(248f + 24.8f, 52f, 49.6f, C.Red, onClick = { end?.invoke() }) {
                GlyphIcon(Glyph.PHONE_DOWN, 26f.pt(), C.White)
            }
            CircleBtn(305f + 24.8f, 52f, 49.6f, C.Green, onClick = { i.act(Act.ACCEPT)?.invoke() }) {
                GlyphIcon(Glyph.PHONE, 26f.pt(), C.White)
            }
        } else {
            i.act(Act.MUTE)?.let { m ->
                CircleBtn(248f + 24.8f, 52f, 49.6f, C.BtnGray, onClick = { m() }) {
                    GlyphIcon(Glyph.MIC, 24f.pt(), C.White)
                }
            }
            CircleBtn(305f + 24.8f, 52f, 49.6f, C.Red, onClick = { end?.invoke() }) {
                GlyphIcon(Glyph.PHONE_DOWN, 26f.pt(), C.White)
            }
        }
    }
}

// --------------------------------------------------------------------- карточка (навигация, уведомления, прочее)

@Composable
private fun CardExpanded(i: IslandItem) {
    Box(Modifier.fillMaxSize()) {
        val icon = i.cover ?: i.appIcon
        if (i.kind == Kind.NAV && i.cover == null) {
            Box(Modifier.at(20f, 28f).size(44f.pt()).clip(RoundedCornerShape(12.74f.pt())).background(C.BtnGray), Alignment.Center) {
                GlyphIcon(Glyph.NAV, 26f.pt(), C.Blue)
            }
        } else {
            BitmapBox(icon, 44f.pt(), 12.74f.pt(), modifier = Modifier.at(20f, 28f))
        }
        val big = i.kind == Kind.NAV
        PtText(
            i.title, if (big) 22f else 16.6f, C.White, FontWeight.SemiBold,
            Modifier.at(76f, if (big) 20f else 24f).width(278f.pt())
        )
        PtText(
            i.subtitle, 15f, C.Secondary, FontWeight.Normal,
            Modifier.at(76f, if (big) 54f else 46f).width(278f.pt()), maxLines = 2
        )
    }
}
