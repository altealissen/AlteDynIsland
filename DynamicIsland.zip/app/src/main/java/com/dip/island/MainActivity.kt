package com.dip.island

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.dip.island.core.Demo
import com.dip.island.core.Prefs
import com.dip.island.core.Root
import com.dip.island.core.Store
import com.dip.island.service.IslandService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val BG = Color(0xFF000000)
private val CARD = Color(0xFF1C1C1E)
private val TXT = Color(0xFFFFFFFF)
private val SEC = Color(0xFF8E8E93)
private val BLUE = Color(0xFF0A84FF)
private val GREEN = Color(0xFF30D158)
private val REDC = Color(0xFFFF453A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContent { Screen() }
    }
}

private fun listenerEnabled(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
    return s.contains(ctx.packageName)
}

private fun startIsland(ctx: Context) {
    ContextCompat.startForegroundService(ctx, Intent(ctx, IslandService::class.java))
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rev by Prefs.rev.collectAsState()
    val running by Store.serviceRunning.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    var rootOk by remember { mutableStateOf<Boolean?>(null) }
    var log by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) { tick++; delay(1000) }
    }
    LaunchedEffect(Unit) { rootOk = Root.runAsync("id").let { it.first == 0 && it.second.contains("uid=0") } }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val refresh = tick + rev
    val overlayOk = refresh >= 0 && Settings.canDrawOverlays(ctx)
    val listenerOk = refresh >= 0 && listenerEnabled(ctx)

    Column(
        Modifier.fillMaxSize().background(BG).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        T("Dynamic Island", 30, TXT, FontWeight.Bold)
        T("Оверлей-остров с root-интеграцией", 14, SEC)

        Card("Состояние") {
            StatusRow("Root", when (rootOk) { true -> "получен"; false -> "нет доступа"; null -> "проверка…" },
                if (rootOk == true) GREEN else if (rootOk == false) REDC else SEC)
            StatusRow("Поверх других окон", if (overlayOk) "разрешено" else "не разрешено", if (overlayOk) GREEN else REDC)
            StatusRow("Доступ к уведомлениям", if (listenerOk) "включён" else "выключен", if (listenerOk) GREEN else REDC)
            StatusRow("Сервис острова", if (running) "работает" else "остановлен", if (running) GREEN else SEC)
        }

        Card("Настройка") {
            Btn(if (busy) "Выдаю права…" else "Выдать все права через root", true) {
                if (!busy) {
                    busy = true
                    scope.launch {
                        val out = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Root.grantAll(ctx) }
                        log = out.joinToString("\n")
                        rootOk = Root.runAsync("id").let { it.first == 0 && it.second.contains("uid=0") }
                        busy = false
                    }
                }
            }
            if (log.isNotEmpty()) T(log, 11, SEC, FontWeight.Normal, mono = true)
            Btn("Разрешение «поверх других окон» вручную") {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                )
            }
            Btn("Доступ к уведомлениям вручную") {
                ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
            if (Build.VERSION.SDK_INT >= 33) {
                Btn("Разрешить уведомления приложения") { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            }
            Btn(if (running) "Остановить остров" else "Запустить остров", !running) {
                if (running) {
                    Prefs.enabled = false
                    ctx.stopService(Intent(ctx, IslandService::class.java))
                } else {
                    Prefs.enabled = true
                    if (Settings.canDrawOverlays(ctx)) startIsland(ctx)
                }
            }
        }

        Card("Источники") {
            Sw("Музыка и медиа", "Now Playing, обложка, управление", Prefs.srcMedia) { Prefs.srcMedia = it }
            Sw("Звонки", "Входящий, разговор, принять и сбросить", Prefs.srcCalls) { Prefs.srcCalls = it }
            Sw("Таймеры и секундомер", "Из приложения «Часы»", Prefs.srcTimers) { Prefs.srcTimers = it }
            Sw("Навигация", "Maps, Яндекс Навигатор, Waze", Prefs.srcNav) { Prefs.srcNav = it }
            Sw("Уведомления", "Баннер в острове вместо heads-up", Prefs.srcNotifs) { Prefs.srcNotifs = it }
            Sw("Системные события", "Зарядка, звук, авиарежим, DND, наушники", Prefs.srcSystem) { Prefs.srcSystem = it }
            Sw("Индикатор микрофона", "Точка в острове при записи звука", Prefs.srcPrivacy) { Prefs.srcPrivacy = it }
        }

        Card("Внешний вид и жесты") {
            Sw("Всегда показывать капсулу", "Чёрная капсула вокруг камеры в покое", Prefs.showIdle) { Prefs.showIdle = it }
            Sw("Контур (keyline)", "Тонкая обводка в раскрытом состоянии", Prefs.keyline) { Prefs.keyline = it }
            Stepper("Размер", "${(Prefs.scale * 100).toInt()} %",
                { Prefs.scale = (Prefs.scale - 0.05f).coerceAtLeast(0.7f) },
                { Prefs.scale = (Prefs.scale + 0.05f).coerceAtMost(1.3f) })
            Stepper("Долгое нажатие", "${Prefs.longPressMs} мс",
                { Prefs.longPressMs = (Prefs.longPressMs - 50).coerceAtLeast(150) },
                { Prefs.longPressMs = (Prefs.longPressMs + 50).coerceAtMost(900) })
            Stepper("Показ алерта", "${Prefs.alertMs / 1000f} с",
                { Prefs.alertMs = (Prefs.alertMs - 500).coerceAtLeast(1000) },
                { Prefs.alertMs = (Prefs.alertMs + 500).coerceAtMost(8000) })
        }

        Card("Root-функции") {
            Sw("Управление через root", "Принять и сбросить вызов, медиаклавиши", Prefs.rootActions) { Prefs.rootActions = it }
            Sw("Скрывать системные баннеры", "Отключает heads-up; остров показывает их сам", Prefs.suppressHeadsUp) {
                Prefs.suppressHeadsUp = it
            }
        }

        Card("Проверка") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { Btn("Музыка") { Demo.music() } }
                Box(Modifier.weight(1f)) { Btn("Таймер") { Demo.timer() } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { Btn("Звонок") { Demo.call() } }
                Box(Modifier.weight(1f)) { Btn("Сообщение") { Demo.notification() } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { Btn("Зарядка") { Demo.charging() } }
                Box(Modifier.weight(1f)) { Btn("Без звука") { Demo.silent() } }
            }
            Btn("Очистить") { Demo.clear() }
        }

        T(
            "Размеры, пружины и цвета взяты из измерений iPhone 16 Pro (DIP_20). Шрифт SF не входит в состав: " +
                "используется системный sans-serif.",
            11, SEC
        )
        Spacer(Modifier.height(32.dp))
    }
}

// ------------------------------------------------------------------ UI-кирпичики

@Composable
private fun Modifier.weight(1f): Modifier = this.then(Modifier.fillMaxWidth(0.49f))

@Composable
private fun T(
    s: String, size: Int, color: Color, weight: FontWeight = FontWeight.Normal, mono: Boolean = false
) {
    BasicText(
        s, style = TextStyle(
            color = color, fontSize = size.sp, fontWeight = weight,
            fontFamily = if (mono) FontFamily.Monospace else FontFamily.SansSerif
        )
    )
}

@Composable
private fun Card(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CARD).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        T(title, 13, SEC, FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun StatusRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) { T(label, 15, TXT) }
        T(value, 14, color, FontWeight.Medium)
    }
}

@Composable
private fun Btn(label: String, primary: Boolean = false, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(14.dp))
            .background(if (primary) BLUE else Color(0xFF2C2C2E))
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(label, 15, TXT, FontWeight.Medium) }
}

@Composable
private fun Sw(label: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val src = remember { MutableInteractionSource() }
    Row(
        Modifier.fillMaxWidth().clickable(interactionSource = src, indication = null) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.fillMaxWidth(0.78f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            T(label, 15, TXT)
            T(desc, 12, SEC)
        }
        Spacer(Modifier.width(8.dp))
        val x by animateDpAsState(if (checked) 22.dp else 2.dp, label = "knob")
        Box(
            Modifier.width(51.dp).height(31.dp).clip(RoundedCornerShape(50))
                .background(if (checked) GREEN else Color(0xFF39393D))
        ) {
            Box(Modifier.offset(x = x, y = 2.dp).size(27.dp).clip(CircleShape).background(Color.White))
        }
    }
}

@Composable
private fun Stepper(label: String, value: String, minus: () -> Unit, plus: () -> Unit) {
    val s1 = remember { MutableInteractionSource() }
    val s2 = remember { MutableInteractionSource() }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.fillMaxWidth(0.5f)) {
            T(label, 15, TXT)
            T(value, 12, SEC)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF2C2C2E))
                .clickable(interactionSource = s1, indication = null, onClick = minus),
            contentAlignment = Alignment.Center
        ) { T("−", 20, TXT) }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF2C2C2E))
                .clickable(interactionSource = s2, indication = null, onClick = plus),
            contentAlignment = Alignment.Center
        ) { T("+", 20, TXT) }
    }
}
