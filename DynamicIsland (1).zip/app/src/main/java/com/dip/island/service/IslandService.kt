package com.dip.island.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.dip.island.MainActivity
import com.dip.island.core.Env
import com.dip.island.core.Geo
import com.dip.island.core.Mode
import com.dip.island.core.Prefs
import com.dip.island.core.Root
import com.dip.island.core.Store
import com.dip.island.core.Target
import com.dip.island.core.Tok
import com.dip.island.ui.IslandRoot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class IslandService : Service() {

    private class Owner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val lr = LifecycleRegistry(this)
        private val ssc = SavedStateRegistryController.create(this)
        private val vms = ViewModelStore()

        init {
            ssc.performAttach()
            ssc.performRestore(null)
            lr.currentState = Lifecycle.State.CREATED
        }

        override val lifecycle: Lifecycle get() = lr
        override val savedStateRegistry: SavedStateRegistry get() = ssc.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = vms
        fun resume() { lr.currentState = Lifecycle.State.RESUMED }
        fun destroy() { lr.currentState = Lifecycle.State.DESTROYED; vms.clear() }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private var view: ComposeView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var owner: Owner? = null
    private var events: SystemEvents? = null
    private var shrinkJob: Job? = null
    private var curW = 0
    private var curH = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        startAsForeground()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Store.serviceRunning.value = true
        buildEnv()
        attachOverlay()
        events = SystemEvents(this).also { it.register() }
        applyRootPrefs()

        scope.launch {
            Prefs.rev.collect {
                buildEnv(); applyRootPrefs()
            }
        }
        scope.launch {
            combine(Store.items, Store.alert, Store.expanded, Store.pinned, Store.env) { items, alert, exp, pin, env ->
                Geo.compute(items, alert, exp, pin, env, Prefs.showIdle)
            }.collect { t ->
                Store.target.value = t
                applyWindow(t)
            }
        }
        scope.launch {
            while (true) {
                delay(500)
                Store.purge(System.currentTimeMillis())
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        Store.serviceRunning.value = false
        events?.unregister()
        scope.cancel()
        try { view?.let { wm.removeView(it) } } catch (e: Exception) { }
        view = null
        owner?.destroy()
        Store.clearAll()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- foreground

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel("dip_service", "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
        val pi = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "dip_service")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Dynamic Island работает")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun applyRootPrefs() {
        val hide = Prefs.suppressHeadsUp
        Thread { Root.setHeadsUp(applicationContext, hide) }.start()
    }

    // ---------------------------------------------------------------- environment

    private fun buildEnv() {
        val dm = resources.displayMetrics
        val density = dm.density
        val sw = dm.widthPixels
        val screenWdp = sw / density
        val maxPt = (screenWdp - 12f) / Tok.EXP_W
        val dpPerPt = min(Tok.DP_PER_PT * Prefs.scale, maxPt)
        val unit = dpPerPt * density
        val topPx = if (cutoutKnown) cutoutCenterY - Tok.CAM_H * unit / 2f else Tok.TOP * unit
        val cx = if (cutoutKnown) cutoutCenterX else sw / 2f
        val shift = if (kotlin.math.abs(cx - sw / 2f) < sw * 0.12f) 0 else (cx - sw / 2f).roundToInt()
        Store.env.value = Env(
            density = density, screenWpx = sw, topPx = max(0f, topPx), shiftPx = shift, dpPerPt = dpPerPt,
            keyline = Prefs.keyline, longPressMs = Prefs.longPressMs, rev = Prefs.rev.value
        )
    }

    private var cutoutKnown = false
    private var cutoutCenterY = 0f
    private var cutoutCenterX = 0f

    private fun readCutout(v: View) {
        if (Build.VERSION.SDK_INT < 28) return
        val cut = v.rootWindowInsets?.displayCutout ?: return
        val r = cut.boundingRects.firstOrNull { it.top <= 2 } ?: return
        cutoutKnown = true
        cutoutCenterY = (r.top + r.bottom) / 2f
        cutoutCenterX = (r.left + r.right) / 2f
        buildEnv()
        lp?.let { it.x = Store.env.value.shiftPx; try { wm.updateViewLayout(v, it) } catch (e: Exception) { } }
    }

    // ---------------------------------------------------------------- window

    private fun attachOverlay() {
        val o = Owner().also { owner = it }
        val cv = ComposeView(this)
        cv.setViewTreeLifecycleOwner(o)
        cv.setViewTreeSavedStateRegistryOwner(o)
        cv.setViewTreeViewModelStoreOwner(o)
        cv.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        cv.setContent { IslandRoot() }
        cv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && Store.expanded.value) Store.expanded.value = false
            false
        }
        cv.setOnApplyWindowInsetsListener { v, insets ->
            v.post { readCutout(v) }
            insets
        }
        val p = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.x = Store.env.value.shiftPx
        p.y = 0
        p.title = "DynamicIsland"
        if (Build.VERSION.SDK_INT >= 30) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(cv, p)
        } catch (e: Exception) {
            // Нет разрешения на наложение: сервис остаётся живым, статус виден в приложении
            stopSelf(); return
        }
        o.resume()
        view = cv
        lp = p
        curW = 1; curH = 1
    }

    /** Окно подгоняется под блок острова, чтобы не перехватывать касания шторки. */
    private fun applyWindow(t: Target) {
        val v = view ?: return
        val p = lp ?: return
        val env = Store.env.value
        val unit = env.dpPerPt * env.density
        val hidden = t.mode == Mode.HIDDEN
        val needW = if (hidden) 1 else
            ((2f * max(-t.blockLeft, t.blockRight) + 2f * Tok.WIN_MARGIN) * unit).roundToInt()
        val needH = if (hidden) 1 else (env.topPx + (t.h + Tok.WIN_MARGIN) * unit).roundToInt()
        val w = min(needW, env.screenWpx)

        fun commit(width: Int, height: Int, touchable: Boolean) {
            curW = width; curH = height
            p.width = width; p.height = height
            p.x = env.shiftPx
            p.flags = if (touchable) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
        }

        if (w >= curW && needH >= curH) {
            shrinkJob?.cancel()
            commit(max(w, curW), max(needH, curH), !hidden)
        } else {
            // Растём сразу, сжимаемся после окончания пружин
            val gw = max(w, curW).takeIf { w > curW } ?: curW
            val gh = max(needH, curH).takeIf { needH > curH } ?: curH
            if (gw != curW || gh != curH) commit(gw, gh, !hidden)
            shrinkJob?.cancel()
            shrinkJob = scope.launch {
                delay(900)
                commit(w, needH, !hidden)
            }
        }
    }
}
