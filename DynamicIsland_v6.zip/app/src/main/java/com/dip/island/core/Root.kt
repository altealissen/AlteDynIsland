package com.dip.island.core

import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Необязательная обёртка над `su`. Пока Prefs.rootMode выключен, `su` не вызывается вообще.
 * Все вызовы блокирующие и с таймаутом: звать из фонового потока.
 */
object Root {
    const val LISTENER = "com.dip.island/com.dip.island.service.DipNotificationListener"
    private const val TAG = "DipRoot"
    private const val TIMEOUT_S = 15L

    private fun exec(cmd: String): Pair<Int, String> {
        return try {
            val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            val sb = StringBuilder()
            val reader = Thread {
                try { sb.append(p.inputStream.bufferedReader().readText()) } catch (_: Exception) { }
            }
            reader.start()
            if (!p.waitFor(TIMEOUT_S, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                reader.interrupt()
                return -3 to "su: таймаут"
            }
            reader.join(500)
            p.exitValue() to sb.toString().trim()
        } catch (e: Exception) {
            Log.w(TAG, "su failed", e)
            -1 to (e.message ?: "su недоступен")
        }
    }

    /** Выполняет команду только в root-режиме. */
    fun run(cmd: String): Pair<Int, String> {
        if (!Prefs.rootMode) return -2 to "root-режим выключен"
        return exec(cmd)
    }

    /** Проверка доступности root независимо от настройки (для переключателя). */
    fun probe(): Boolean {
        val r = exec("id")
        return r.first == 0 && r.second.contains("uid=0")
    }

    suspend fun probeAsync(): Boolean = withContext(Dispatchers.IO) { probe() }

    /** Выдаёт все нужные разрешения без ручных шагов в настройках. Возвращает лог. */
    fun grantAll(ctx: Context): List<String> {
        if (!Prefs.rootMode) return listOf("Включите «Режим root», чтобы использовать выдачу прав")
        val pkg = ctx.packageName
        val cmds = mutableListOf<String>()
        cmds += "appops set $pkg ACCESS_RESTRICTED_SETTINGS allow"
        cmds += "appops set $pkg SYSTEM_ALERT_WINDOW allow"
        if (Build.VERSION.SDK_INT >= 33) cmds += "pm grant $pkg android.permission.POST_NOTIFICATIONS"
        cmds += "pm grant $pkg android.permission.READ_PHONE_STATE"
        cmds += "pm grant $pkg android.permission.ANSWER_PHONE_CALLS"
        if (Build.VERSION.SDK_INT >= 31) cmds += "pm grant $pkg android.permission.BLUETOOTH_CONNECT"
        cmds += "cmd notification allow_listener ${LISTENER}"
        val a11y = "com.dip.island/com.dip.island.service.DipAccessibilityService"
        cmds += "cur=\$(settings get secure enabled_accessibility_services); case \"\$cur\" in *DipAccessibilityService*) ;; null|\"\") settings put secure enabled_accessibility_services $a11y;; *) settings put secure enabled_accessibility_services \"\$cur:$a11y\";; esac; settings put secure accessibility_enabled 1"
        cmds += "cmd deviceidle whitelist +$pkg"
        cmds += "appops set $pkg RUN_IN_BACKGROUND allow"
        cmds += "appops set $pkg RUN_ANY_IN_BACKGROUND allow"
        return cmds.map { c ->
            val r = run(c)
            (if (r.first == 0) "OK   " else "FAIL ") + c.removePrefix("pm grant $pkg ").take(70)
        }
    }

    /** Состояние текущего звонка из `dumpsys telecom` (root). 0 активен, 1 соединение, 2 удержание, -1 неизвестно. */
    fun callState(): Int {
        val out = run("dumpsys telecom").second
        if (out.isEmpty()) return -1
        val m = Regex("""(?i)\bstate[:=]\s*(ACTIVE|ON_HOLD|HOLDING|DIALING|CONNECTING|PULLING|RINGING)""")
            .findAll(out).map { it.groupValues[1].uppercase() }.toList()
        return when {
            m.any { it == "ON_HOLD" || it == "HOLDING" } && m.none { it == "ACTIVE" } -> 2
            m.any { it == "DIALING" || it == "CONNECTING" || it == "PULLING" } && m.none { it == "ACTIVE" } -> 1
            m.any { it == "ACTIVE" } -> 0
            else -> -1
        }
    }

    fun key(code: Int) = run("input keyevent $code")
    fun answerCall() = key(5)
    fun endCall() = key(6)

    /** Подавление системных heads-up баннеров (только root). Возвращает true, если значение менялось. */
    fun setHeadsUp(ctx: Context, hide: Boolean) {
        if (!Prefs.rootMode && hide) return
        val sp = ctx.getSharedPreferences("dip_root", Context.MODE_PRIVATE)
        if (hide) {
            if (!sp.contains("heads_prev")) {
                val cur = run("settings get global heads_up_notifications_enabled").second.trim()
                sp.edit().putString("heads_prev", if (cur == "null" || cur.isEmpty()) "1" else cur).apply()
            }
            run("settings put global heads_up_notifications_enabled 0")
        } else {
            // Восстанавливаем только то, что сами меняли, чужие настройки не трогаем
            val prev = sp.getString("heads_prev", null) ?: return
            if (exec("settings put global heads_up_notifications_enabled $prev").first == 0 || !Prefs.rootMode) {
                sp.edit().remove("heads_prev").apply()
            }
        }
    }
}
