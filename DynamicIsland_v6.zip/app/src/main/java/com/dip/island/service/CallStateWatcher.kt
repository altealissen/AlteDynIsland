package com.dip.island.service

import android.os.Handler
import android.os.Looper
import com.dip.island.core.Kind
import com.dip.island.core.Prefs
import com.dip.island.core.Root
import com.dip.island.core.Store

/** Root: пока идёт звонок, раз в 2 с читает состояние из telecom (удержание, соединение). */
object CallStateWatcher {
    private val main = Handler(Looper.getMainLooper())
    private var running = false
    private var busy = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val call = Store.items.value.values.firstOrNull { it.kind == Kind.CALL && !it.incoming }
            if (Prefs.rootMode && Prefs.srcCalls && call != null && !busy) {
                busy = true
                Thread {
                    val st = try { Root.callState() } catch (e: Exception) { -1 }
                    main.post {
                        busy = false
                        val cur = Store.items.value[call.id]
                        if (st >= 0 && cur != null && cur.callState != st) Store.put(cur.copy(callState = st))
                    }
                }.start()
            }
            main.postDelayed(this, 2000L)
        }
    }

    fun start() {
        if (running) return
        running = true
        main.postDelayed(tick, 2000L)
    }

    fun stop() {
        running = false
        main.removeCallbacks(tick)
    }
}
