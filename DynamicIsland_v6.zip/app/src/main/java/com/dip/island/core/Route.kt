package com.dip.island.core

/**
 * Разбор уведомлений такси и доставки: время прибытия, машина и госномер.
 * Чистая функция без Android-зависимостей.
 */
object Route {
    class Info(
        /** Короткая подпись для compact и expanded: «4 мин», «1 ч 05 мин» или время «14:32». */
        val etaText: String,
        /** Минуты до прибытия; -1, если в тексте указано только время суток. */
        val etaMin: Int,
        /** Машина и номер: «Toyota Camry · А123ВС777». */
        val detail: String
    )

    private val minRe = Regex("""(\d{1,3})\s*(?:мин|min)""", RegexOption.IGNORE_CASE)
    private val hourRe = Regex("""(\d{1,2})\s*(?:ч|час|hr|h)(?![a-zа-я])""", RegexOption.IGNORE_CASE)
    private val clockRe = Regex("""(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)""")
    private val plateRe = Regex("""[A-ZА-Я]\s?\d{3}\s?[A-ZА-Я]{2}\s?\d{2,3}""")
    private val trimChars = charArrayOf(' ', '·', ',', ';', '-', '–', '—', '•', '|', '(', ')', ':')

    fun parse(title: String, text: String, sub: String = ""): Info {
        val blob = listOf(text, sub, title).filter { it.isNotBlank() }.joinToString(" · ")
        val m = minRe.find(blob)
        val h = hourRe.find(blob)
        var etaMin = -1
        var etaText = ""
        if (m != null || h != null) {
            val mins = m?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val hrs = h?.groupValues?.get(1)?.toIntOrNull() ?: 0
            etaMin = hrs * 60 + mins
            etaText = when {
                hrs > 0 && mins > 0 -> "$hrs ч %02d мин".format(mins)
                hrs > 0 -> "$hrs ч"
                else -> "$mins мин"
            }
        } else {
            clockRe.find(blob)?.let { etaText = "%d:%s".format(it.groupValues[1].toInt(), it.groupValues[2]) }
        }
        // Описание берём из текста уведомления (не из заголовка): убираем время и номер
        var car = text.ifBlank { sub }
        val pm = plateRe.find(car.uppercase())
        val plate = pm?.value?.replace(" ", "")
        if (pm != null && pm.range.last < car.length) car = car.removeRange(pm.range)
        car = minRe.replace(car, "")
        car = hourRe.replace(car, "")
        car = clockRe.replace(car, "")
        car = car.replace(Regex("""\b(arriving|arrives|arrival|arrive|in)\b""", RegexOption.IGNORE_CASE), "")
        car = car.replace(Regex("""(через|приедет|будет)""", RegexOption.IGNORE_CASE), "")
        car = car.replace(Regex("""\s{2,}"""), " ").trim(*trimChars)
        val detail = listOf(car, plate ?: "").filter { it.isNotBlank() }.joinToString(" · ")
        return Info(etaText, etaMin, detail)
    }
}
