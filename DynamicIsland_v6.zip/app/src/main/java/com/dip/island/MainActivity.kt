package com.dip.island

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import com.dip.island.core.Demo
import com.dip.island.core.Prefs
import com.dip.island.service.DipAccessibilityService
import com.dip.island.core.Root
import com.dip.island.core.Store
import com.dip.island.service.IslandService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val BG = Color(0xFF000000)
private val CARD = Color(0xFF1C1C1E)
private val TXT = Color(0xFFFFFFFF)
private val SEC = Color(0xFF8E8E93)
private val BLUE = Color(0xFF0A84FF)
private val GREEN = Color(0xFF30D158)
private val REDC = Color(0xFFFF453A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContent { Screen() }
    }

    override fun onPause() {
        // Контур настройки показываем только пока приложение открыто
        Store.calibrate.value = false
        super.onPause()
    }
}

private fun listenerEnabled(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
    return s.contains(ctx.packageName)
}

private fun startIsland(ctx: Context) {
    ContextCompat.startForegroundService(ctx, Intent(ctx, IslandService::class.java))
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rev by Prefs.rev.collectAsState()
    val running by Store.serviceRunning.collectAsState()
    val calibrating by Store.calibrate.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    var rootOk by remember { mutableStateOf<Boolean?>(null) }
    var rootMsg by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) { tick++; delay(1000) }
    }
    // su вызывается только если пользователь сам включил root-режим
    val rootMode = Prefs.rootMode
    LaunchedEffect(rootMode) {
        rootOk = if (rootMode) Root.probeAsync() else null
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    val refresh = tick + rev
    val overlayOk = refresh >= 0 && Settings.canDrawOverlays(ctx)
    val listenerOk = refresh >= 0 && listenerEnabled(ctx)
    val a11yOk = refresh >= 0 && DipAccessibilityService.isEnabled(ctx)
    val phoneOk = refresh >= 0 && has(ctx, Manifest.permission.ANSWER_PHONE_CALLS) &&
        has(ctx, Manifest.permission.READ_PHONE_STATE)

    Column(
        Modifier.fillMaxSize().background(BG).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        T("Dynamic Island", 30, TXT, FontWeight.Bold)
        T(if (rootMode) "Режим: root" else "Режим: без root", 14, SEC)

        Card("Состояние") {
            StatusRow(
                "Root",
                when {
                    !rootMode -> "не требуется"
                    rootOk == true -> "получен"
                    rootOk == false -> "нет доступа"
                    else -> "проверка…"
                },
                when { !rootMode -> SEC; rootOk == true -> GREEN; rootOk == false -> REDC; else -> SEC }
            )
            StatusRow("Поверх других окон", if (overlayOk) "разрешено" else "не разрешено", if (overlayOk) GREEN else REDC)
            StatusRow("Доступ к уведомлениям", if (listenerOk) "включён" else "выключен", if (listenerOk) GREEN else REDC)
            StatusRow("Касания у камеры (спец. возможности)", if (a11yOk) "включено" else "выключено", if (a11yOk) GREEN else REDC)
            StatusRow("Телефон (принять/сбросить)", if (phoneOk) "разрешено" else "не разрешено", if (phoneOk) GREEN else SEC)
            StatusRow("Сервис острова", if (running) "работает" else "остановлен", if (running) GREEN else SEC)
        }

        Card("Режим работы") {
            Sw("Использовать root", "Необязательно. Всё остальное работает и без него", rootMode) { want ->
                if (!want) {
                    Prefs.rootMode = false
                    rootMsg = ""
                } else {
                    scope.launch {
                        if (Root.probeAsync()) {
                            Prefs.rootMode = true
                            rootMsg = ""
                        } else {
                            Prefs.rootMode = false
                            rootMsg = "Root не получен. Остаёмся в режиме без root."
                        }
                    }
                }
            }
            if (rootMsg.isNotEmpty()) T(rootMsg, 12, REDC)
            if (rootMode) {
                Btn(if (busy) "Выдаю права…" else "Выдать все права через root", true) {
                    if (!busy) {
                        busy = true
                        scope.launch {
                            val out = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Root.grantAll(ctx) }
                            log = out.joinToString("\n")
                            busy = false
                        }
                    }
                }
                if (log.isNotEmpty()) T(log, 11, SEC, FontWeight.Normal, mono = true)
                Sw("Скрывать системные баннеры", "Отключает heads-up; остров показывает их сам", Prefs.suppressHeadsUp) {
                    Prefs.suppressHeadsUp = it
                }
            }
        }

        Card("Настройка без root (по шагам)") {
            T("1. Поверх других окон", 13, SEC)
            Btn(if (overlayOk) "Готово ✓" else "Открыть настройку", !overlayOk) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                )
            }
            T("2. Доступ к уведомлениям", 13, SEC)
            Btn(if (listenerOk) "Готово ✓" else "Открыть настройку", !listenerOk) {
                ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
            if (Build.VERSION.SDK_INT >= 33 && (!listenerOk || !a11yOk)) {
                T(
                    "Если переключатель серый: «О приложении» → меню ⋮ → «Разрешить ограниченные настройки», затем повторите шаг 2 или 3.",
                    12, SEC
                )
                Btn("Открыть «О приложении»") {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    )
                }
            }
            T("3. Касания у камеры", 13, SEC)
            T(
                "Если камера на уровне строки состояния, обычный оверлей не получает там касания: жест открывает шторку. " +
                    "Включите «Dynamic Island» в «Специальных возможностях». Приложение ничего не читает с экрана.",
                12, SEC
            )
            Btn(if (a11yOk) "Готово ✓" else "Открыть спец. возможности", !a11yOk) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            T("4. Телефон, уведомления, Bluetooth", 13, SEC)
            Btn(if (phoneOk) "Повторить запрос" else "Разрешить", !phoneOk) {
                val list = mutableListOf(
                    Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS
                )
                if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
                if (Build.VERSION.SDK_INT >= 31) list += Manifest.permission.BLUETOOTH_CONNECT
                permLauncher.launch(list.toTypedArray())
            }
            T("5. Не давать системе усыплять остров", 13, SEC)
            Btn("Исключить из экономии батареи") {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: Exception) { }
            }
            T("6. Запуск", 13, SEC)
            Btn(if (running) "Остановить остров" else "Запустить остров", !running) {
                if (running) {
                    Prefs.enabled = false
                    ctx.stopService(Intent(ctx, IslandService::class.java))
                } else {
                    Prefs.enabled = true
                    if (Settings.canDrawOverlays(ctx)) startIsland(ctx)
                }
            }
        }

        Card("Положение острова") {
            T(
                "Нажмите «Показать контур» и двигайте ползунки: остров ставится по любой оси. " +
                    "Значения прибавляются к автоопределению выреза камеры.",
                12, SEC
            )
            Btn(if (calibrating) "Скрыть контур" else "Показать контур", !calibrating) {
                Store.calibrate.value = !calibrating
            }
            if (calibrating && !running) T("Запустите остров, чтобы увидеть контур.", 12, REDC)
            Adjust("Сдвиг по X (← →)", fmt(Prefs.offX, "dp"), Prefs.offX,
                -Prefs.OFF_X_MAX, Prefs.OFF_X_MAX, 0.5f) { Prefs.offX = it }
            Adjust("Сдвиг по Y (↑ ↓)", fmt(Prefs.offY, "dp"), Prefs.offY,
                Prefs.OFF_Y_MIN, Prefs.OFF_Y_MAX, 0.5f) { Prefs.offY = it }
            Adjust("Ширина капсулы", fmt(Prefs.adjW, "pt"), Prefs.adjW,
                Prefs.ADJ_W_MIN, Prefs.ADJ_W_MAX, 0.5f) { Prefs.adjW = it }
            Adjust("Высота капсулы", fmt(Prefs.adjH, "pt"), Prefs.adjH,
                Prefs.ADJ_H_MIN, Prefs.ADJ_H_MAX, 0.5f) { Prefs.adjH = it }
            Adjust("Общий размер", "${(Prefs.scale * 100).roundToInt()} %", Prefs.scale,
                0.7f, 1.3f, 0.01f) { Prefs.scale = it }
            Btn("Сбросить положение") { Prefs.resetPosition() }
        }

        Card("Источники") {
            Sw("Музыка и медиа", "Now Playing, обложка, управление", Prefs.srcMedia) { Prefs.srcMedia = it }
            Sw("Звонки", "Входящий, разговор, принять и сбросить", Prefs.srcCalls) { Prefs.srcCalls = it }
            Sw("Таймеры и секундомер", "Из приложения «Часы»", Prefs.srcTimers) { Prefs.srcTimers = it }
            Sw("Навигация", "Maps, Яндекс Навигатор, Waze", Prefs.srcNav) { Prefs.srcNav = it }
            Sw("Уведомления", "Баннер в острове", Prefs.srcNotifs) { Prefs.srcNotifs = it }
            Sw("Системные события", "Зарядка, звук, авиарежим, DND, наушники", Prefs.srcSystem) { Prefs.srcSystem = it }
            Sw("Индикатор микрофона", "Точка в острове при записи звука", Prefs.srcPrivacy) { Prefs.srcPrivacy = it }
            Sw("Индикатор камеры", "Точка в острове, когда камеру занимает приложение", Prefs.srcCamera) { Prefs.srcCamera = it }
            Sw("Живые активности", "Такси, доставка, загрузки, прогресс из других приложений", Prefs.srcLive) { Prefs.srcLive = it }
            Sw("Определять автоматически", "Иначе только приложения, выбранные вручную", Prefs.liveAuto) { Prefs.liveAuto = it }
            Sw("Переключатели", "Wi-Fi, NFC, точка доступа", Prefs.srcToggles) { Prefs.srcToggles = it }
            Sw("Громкость", "Алерт при изменении громкости мультимедиа", Prefs.srcVolume) { Prefs.srcVolume = it }
            Sw("Разблокировка", "Алерт с замком после разблокировки", Prefs.srcUnlock) { Prefs.srcUnlock = it }
        }

        Card("Живые активности: приложения") {
            Sw("Раскрывать при обновлении", "Остров кратко раскрывается, когда меняется текст", Prefs.expandOnUpdate) { Prefs.expandOnUpdate = it }
            val seen = Prefs.liveSet(Prefs.SEEN).toList().sorted().take(12)
            if (seen.isEmpty()) {
                T("Список появится, когда приложения опубликуют постоянные уведомления", 12, SEC)
            }
            val on = Prefs.liveSet(Prefs.LIVE_ON)
            val off = Prefs.liveSet(Prefs.LIVE_OFF)
            seen.forEach { p ->
                val label = com.dip.island.core.Util.appLabel(ctx, p)
                Sw(label, if (p in off) "Исключено" else if (p in on) "Включено вручную" else "Автоопределение", p !in off) { v ->
                    Prefs.liveToggle(Prefs.LIVE_OFF, p, !v)
                    Prefs.liveToggle(Prefs.LIVE_ON, p, v)
                }
            }
        }

        Card("Внешний вид и жесты") {
            Sw("Всегда показывать капсулу", "Чёрная капсула вокруг камеры в покое", Prefs.showIdle) { Prefs.showIdle = it }
            Sw("Три активности", "Второй пузырь слева от острова (до трёх активностей)", Prefs.threeSlots) { Prefs.threeSlots = it }
            Sw("Свайп скрывает активность", "Влево — скрыть, вправо — вернуть; иначе свайп переключает", Prefs.swipeHide) { Prefs.swipeHide = it }
            Sw("Контур (keyline)", "Тонкая обводка в раскрытом состоянии и у постоянной капсулы", Prefs.keyline) { Prefs.keyline = it }
            Sw("Размытие при появлении", "Выключите, если анимации тормозят", Prefs.blurFx) { Prefs.blurFx = it }
            Stepper("Долгое нажатие", "${Prefs.longPressMs} мс",
                { Prefs.longPressMs = (Prefs.longPressMs - 50).coerceAtLeast(150) },
                { Prefs.longPressMs = (Prefs.longPressMs + 50).coerceAtMost(900) })
            Stepper("Показ алерта", "${Prefs.alertMs / 1000f} с",
                { Prefs.alertMs = (Prefs.alertMs - 500).coerceAtLeast(1000) },
                { Prefs.alertMs = (Prefs.alertMs + 500).coerceAtMost(8000) })
        }

        Card("Проверка") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { Btn("Музыка") { Demo.music() } }
                Box(Modifier.weight(1f)) { Btn("Таймер") { Demo.timer() } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { Btn("Звонок") { Demo.call() } }
                Box(Modifier.weight(1f)) { Btn("Сообщение") { Demo.notification() } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { Btn("Зарядка") { Demo.charging() } }
                Box(Modifier.weight(1f)) { Btn("Без звука") { Demo.silent() } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { Btn("Такси") { Demo.taxi() } }
                Box(Modifier.weight(1f)) { Btn("Загрузка") { Demo.download() } }
                Box(Modifier.weight(1f)) { Btn("Доставка") { Demo.delivery() } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { Btn("Будильник") { Demo.alarm() } }
                Box(Modifier.weight(1f)) { Btn("Запись") { Demo.recording() } }
            }
            Btn("Wi-Fi, NFC, громкость") { Demo.toggles() }
            Btn("Очистить") { Demo.clear() }
        }

        T(
            "Размеры, пружины и цвета взяты из измерений iPhone 16 Pro (DIP_20). Шрифт SF не входит в состав: " +
                "используется системный sans-serif.",
            11, SEC
        )
        Spacer(Modifier.height(32.dp))
    }
}

private fun has(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == android.content.pm.PackageManager.PERMISSION_GRANTED

private fun fmt(v: Float, unit: String): String {
    val r = (v * 10).roundToInt() / 10f
    return (if (r > 0) "+" else "") + r + " " + unit
}

// ------------------------------------------------------------------ UI-кирпичики

@Composable
private fun T(
    s: String, size: Int, color: Color, weight: FontWeight = FontWeight.Normal, mono: Boolean = false
) {
    BasicText(
        s, style = TextStyle(
            color = color, fontSize = size.sp, fontWeight = weight,
            fontFamily = if (mono) FontFamily.Monospace else FontFamily.SansSerif
        )
    )
}

@Composable
private inline fun Card(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CARD).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        T(title, 13, SEC, FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun StatusRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) { T(label, 15, TXT) }
        T(value, 14, color, FontWeight.Medium)
    }
}

@Composable
private fun Btn(label: String, primary: Boolean = false, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(14.dp))
            .background(if (primary) BLUE else Color(0xFF2C2C2E))
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(label, 15, TXT, FontWeight.Medium) }
}

@Composable
private fun Sw(label: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val src = remember { MutableInteractionSource() }
    Row(
        Modifier.fillMaxWidth().clickable(interactionSource = src, indication = null) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.fillMaxWidth(0.78f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            T(label, 15, TXT)
            T(desc, 12, SEC)
        }
        Spacer(Modifier.width(8.dp))
        val x by animateDpAsState(if (checked) 22.dp else 2.dp, label = "knob")
        Box(
            Modifier.width(51.dp).height(31.dp).clip(RoundedCornerShape(50))
                .background(if (checked) GREEN else Color(0xFF39393D))
        ) {
            Box(Modifier.offset(x = x, y = 2.dp).size(27.dp).clip(CircleShape).background(Color.White))
        }
    }
}

@Composable
private fun Stepper(label: String, value: String, minus: () -> Unit, plus: () -> Unit) {
    val s1 = remember { MutableInteractionSource() }
    val s2 = remember { MutableInteractionSource() }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.fillMaxWidth(0.5f)) {
            T(label, 15, TXT)
            T(value, 12, SEC)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF2C2C2E))
                .clickable(interactionSource = s1, indication = null, onClick = minus),
            contentAlignment = Alignment.Center
        ) { T("−", 20, TXT) }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF2C2C2E))
                .clickable(interactionSource = s2, indication = null, onClick = plus),
            contentAlignment = Alignment.Center
        ) { T("+", 20, TXT) }
    }
}

@Composable
private fun RoundBtn(label: String, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF2C2C2E))
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(label, 20, TXT) }
}

@Composable
private fun Adjust(
    label: String, valueText: String, value: Float, min: Float, max: Float, step: Float,
    onChange: (Float) -> Unit
) {
    val cur by rememberUpdatedState(value)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { T(label, 15, TXT) }
            T(valueText, 13, SEC)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            RoundBtn("−") { onChange((cur - step).coerceIn(min, max)) }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) { SliderBar(value, min, max, step, onChange) }
            Spacer(Modifier.width(8.dp))
            RoundBtn("+") { onChange((cur + step).coerceIn(min, max)) }
        }
    }
}

@Composable
private fun SliderBar(value: Float, min: Float, max: Float, step: Float, onChange: (Float) -> Unit) {
    val density = LocalDensity.current
    val thumbPx = with(density) { 24.dp.roundToPx() }
    var w by remember { mutableIntStateOf(1) }
    val upd by rememberUpdatedState(onChange)
    val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)

    fun snap(x: Float): Float {
        val span = (w - thumbPx).coerceAtLeast(1)
        val f = ((x - thumbPx / 2f) / span).coerceIn(0f, 1f)
        val raw = min + f * (max - min)
        return ((raw / step).roundToInt() * step).coerceIn(min, max)
    }

    Box(
        Modifier.fillMaxWidth().height(36.dp)
            .onSizeChanged { w = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) { detectTapGestures { o -> upd(snap(o.x)) } }
            .pointerInput(Unit) { detectDragGestures { change, _ -> change.consume(); upd(snap(change.position.x)) } },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF39393D)))
        Box(Modifier.fillMaxWidth(frac).height(4.dp).clip(RoundedCornerShape(2.dp)).background(BLUE))
        Box(
            Modifier.offset { IntOffset(((w - thumbPx).coerceAtLeast(0) * frac).roundToInt(), 0) }
                .size(24.dp).clip(CircleShape).background(Color.White)
        )
    }
}
