package com.dip.island.service

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.view.KeyEvent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.dip.island.core.Act
import com.dip.island.core.Actions
import com.dip.island.core.Glyph
import com.dip.island.core.Route
import com.dip.island.core.IslandAction
import com.dip.island.core.IslandAlert
import com.dip.island.core.IslandItem
import com.dip.island.core.Kind
import com.dip.island.core.Prefs
import com.dip.island.core.Store
import com.dip.island.core.Util

/**
 * Источник данных: медиасессии, звонки, таймеры, навигация и обычные уведомления.
 * Содержимое уведомлений обрабатывается только в памяти и нигде не сохраняется.
 */
class DipNotificationListener : NotificationListenerService() {

    private var sessions: MediaSessionManager? = null
    private val callbacks = HashMap<String, Pair<MediaController, MediaController.Callback>>()

    private val navPkgs = setOf(
        "com.google.android.apps.maps", "ru.yandex.yandexnavi", "ru.yandex.yandexmaps",
        "com.waze", "com.here.app.maps", "net.osmand", "net.osmand.plus", "app.organicmaps"
    )
    private val clockPkgs = setOf(
        "com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage",
        "com.miui.clock", "com.oneplus.deskclock", "com.coloros.alarmclock", "com.huawei.deskclock"
    )

    private val recPkgs = setOf(
        "com.google.android.apps.recorder", "com.samsung.android.app.voicenote", "com.miui.screenrecorder",
        "com.android.soundrecorder", "com.sec.android.app.soundrecorder", "com.oplus.soundrecorder",
        "com.hihonor.soundrecorder", "com.huawei.soundrecorder", "com.android.systemui.screenrecord"
    )
    private val payPkgs = setOf(
        "com.google.android.apps.walletnfcrel", "com.samsung.android.spay", "com.mi.global.pay",
        "ru.sberbankmobile", "ru.sberbank.mobile", "ru.tinkoff.mobile", "com.huawei.wallet"
    )
    private val shareHints = listOf("nearby", "sharelive", "quickshare", "quick_share", "xiaomi.midrop", "oplus.ocs", "airdrop")
    private val etaStart = HashMap<String, Int>()
    private val taxiHints = listOf("taxi", "uber", "bolt", "lyft", "yango", "didi", "gett")
    private val foodHints = listOf("eda", "food", "delivery", "lavka", "wolt", "glovo", "doordash", "ubereats", "samokat", "market")
    private val trainHints = listOf("rzd", "train", "rail", "flight", "avia", "aero", "tutu", "airlines")

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        syncSessions(list ?: emptyList())
    }

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }

    override fun onListenerConnected() {
        Prefs.init(this)
        Store.listenerConnected.value = true
        try {
            val cn = ComponentName(this, DipNotificationListener::class.java)
            val m = getSystemService(MediaSessionManager::class.java)
            sessions = m
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
            syncSessions(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
        } catch (e: Exception) {
        }
        try {
            activeNotifications?.forEach { process(it, initial = true) }
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        Store.listenerConnected.value = false
        try { sessions?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
        callbacks.values.forEach { try { it.first.unregisterCallback(it.second) } catch (e: Exception) { } }
        callbacks.clear()
        Store.removeWhere { it.kind != Kind.RECORDING }
        // Система могла остановить слушатель: просим подключить его заново
        try { NotificationListenerService.requestRebind(ComponentName(this, DipNotificationListener::class.java)) } catch (e: Exception) { }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try { process(sbn, initial = false) } catch (e: Exception) { android.util.Log.w("DipListener", "posted", e) }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val k = sbn.key
        Store.remove("call:$k"); Store.remove("timer:$k"); Store.remove("n:$k")
        Store.remove("live:$k"); Store.remove("rec:$k")
        synchronized(etaStart) { etaStart.remove(k) }
        if (Store.items.value.containsKey("nav:$k")) {
            Store.remove("nav:$k")
            if (Prefs.srcNav) Store.alert(IslandAlert("nav:end", "Навигация завершена", "", 0xFFFFFFFF, Glyph.NAV, 0xFF0A84FF))
        }
    }

    // ---------------------------------------------------------------- media

    private fun syncSessions(list: List<MediaController>) {
        val alive = list.map { it.packageName }.toSet()
        callbacks.keys.filter { it !in alive }.forEach { pkg ->
            callbacks.remove(pkg)?.let { try { it.first.unregisterCallback(it.second) } catch (e: Exception) { } }
            Store.remove("media:$pkg")
        }
        for (c in list) {
            val pkg = c.packageName
            val known = callbacks[pkg]
            if (known == null || known.first.sessionToken != c.sessionToken) {
                known?.let { try { it.first.unregisterCallback(it.second) } catch (e: Exception) { } }
                val cb = object : MediaController.Callback() {
                    override fun onPlaybackStateChanged(state: PlaybackState?) = publishMedia(c)
                    override fun onMetadataChanged(metadata: MediaMetadata?) = publishMedia(c)
                    override fun onSessionDestroyed() {
                        Store.remove("media:$pkg"); callbacks.remove(pkg)
                    }
                }
                c.registerCallback(cb)
                callbacks[pkg] = c to cb
            }
            publishMedia(c)
        }
    }

    private fun publishMedia(c: MediaController) {
        val pkg = c.packageName
        val id = "media:$pkg"
        if (!Prefs.srcMedia) {
            Store.remove(id); return
        }
        val st = c.playbackState
        val state = st?.state ?: PlaybackState.STATE_NONE
        if (state == PlaybackState.STATE_NONE || state == PlaybackState.STATE_STOPPED ||
            state == PlaybackState.STATE_ERROR
        ) {
            Store.remove(id); return
        }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val art: Bitmap? = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val playing = state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING
        val old = Store.items.value[id]
        val tc = c.transportControls
        val caps = st?.actions ?: 0L
        val canPrev = (caps and PlaybackState.ACTION_SKIP_TO_PREVIOUS) != 0L
        val canNext = (caps and PlaybackState.ACTION_SKIP_TO_NEXT) != 0L
        val svc = this@DipNotificationListener
        val canSeek = (caps and PlaybackState.ACTION_SEEK_TO) != 0L
        // Транспорт-команда ИЛИ медиаклавиша (не обе сразу: иначе трек пропускается дважды)
        val actions = listOf(
            IslandAction(Act.PREV, "prev") {
                try {
                    if (canPrev) tc.skipToPrevious() else Actions.mediaKey(svc, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                } catch (e: Exception) { Actions.mediaKey(svc, KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
            },
            IslandAction(if (playing) Act.PAUSE else Act.PLAY, "play") {
                try {
                    if (playing) tc.pause() else tc.play()
                } catch (e: Exception) { Actions.mediaKey(svc, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
            },
            IslandAction(Act.NEXT, "next") {
                try {
                    if (canNext) tc.skipToNext() else Actions.mediaKey(svc, KeyEvent.KEYCODE_MEDIA_NEXT)
                } catch (e: Exception) { Actions.mediaKey(svc, KeyEvent.KEYCODE_MEDIA_NEXT) }
            }
        )
        val open: () -> Unit = {
            try {
                val pi = c.sessionActivity
                if (pi != null) pi.send() else launch(pkg)
            } catch (e: Exception) {
                launch(pkg)
            }
        }
        val cover = art ?: old?.cover
        Store.put(
            IslandItem(
                id = id, kind = Kind.MEDIA, pkg = pkg, title = title, subtitle = artist,
                cover = cover ?: Util.appIcon(this, pkg), appIcon = old?.appIcon ?: Util.appIcon(this, pkg),
                accent = Util.dominant(cover), playing = playing,
                positionMs = st?.position ?: 0L,
                durationMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
                speed = st?.playbackSpeed ?: 1f,
                stampElapsed = st?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
                actions = actions, open = open,
                seek = if (canSeek) ({ ms: Long -> try { tc.seekTo(ms) } catch (e: Exception) { } }) else null,
                // Пауза: показываем ещё 30 секунд, как в системе
                expiresAt = if (playing) 0L else System.currentTimeMillis() + 30_000L,
                updated = old?.takeIf { it.playing == playing }?.updated ?: System.currentTimeMillis()
            )
        )
    }

    private fun launch(pkg: String) {
        try {
            packageManager.getLaunchIntentForPackage(pkg)?.let {
                it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(it)
            }
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------- notifications

    private fun process(sbn: StatusBarNotification, initial: Boolean) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val ex = n.extras ?: return
        if (ex.containsKey(Notification.EXTRA_MEDIA_SESSION)) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val pkg = sbn.packageName
        val cat = n.category
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
        val chrono = ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
        val countdown = ex.getBoolean("android.chronometerCountDown", false)

        when {
            cat == Notification.CATEGORY_CALL || cat == "call" -> if (Prefs.srcCalls) call(sbn, n, title, text, chrono)
            cat == Notification.CATEGORY_NAVIGATION || pkg in navPkgs ->
                if (Prefs.srcNav && sbn.isOngoing) nav(sbn, n, title, text)
            (pkg in clockPkgs || cat == Notification.CATEGORY_ALARM || cat == "stopwatch") &&
                (chrono || sbn.isOngoing) ->
                if (Prefs.srcTimers) timer(sbn, n, title, text, chrono, countdown)
            pkg in payPkgs && !sbn.isOngoing -> if (Prefs.srcLive) pay(sbn, n, title, text)
            pkg == "com.google.android.apps.adm" && !sbn.isOngoing -> if (Prefs.srcLive) findMy(sbn, n, title, text)
            pkg in recPkgs && sbn.isOngoing -> if (Prefs.srcPrivacy) recording(sbn, n, title, text)
            cat == Notification.CATEGORY_ALARM && !sbn.isOngoing -> if (Prefs.srcTimers) alarm(sbn, n, title, text)
            sbn.isOngoing -> if (Prefs.srcLive && !initialSkip(pkg)) live(sbn, n, title, text, chrono)
            else -> if (Prefs.srcNotifs && !initial) generic(sbn, n, title, text)
        }
    }

    private fun actionsOf(n: Notification): List<IslandAction> {
        val out = ArrayList<IslandAction>()
        n.actions?.forEach { a ->
            val label = a.title?.toString().orEmpty()
            val l = label.lowercase()
            val act = when {
                Regex("answer|accept|ответ|принять").containsMatchIn(l) -> Act.ACCEPT
                Regex("decline|reject|dismiss|отклон|отбой").containsMatchIn(l) -> Act.DECLINE
                Regex("hang|end|заверш|положить|сбросить").containsMatchIn(l) -> Act.HANGUP
                Regex("stop|reset|delete|остан|сброс|удал").containsMatchIn(l) -> Act.STOP
                Regex("pause|пауза|resume|продолж|start|старт").containsMatchIn(l) -> Act.PAUSE
                Regex("mute|без звука|микрофон").containsMatchIn(l) -> Act.MUTE
                else -> Act.OTHER
            }
            val pi = a.actionIntent
            if (pi != null && a.remoteInputs.isNullOrEmpty()) {
                out += IslandAction(act, label) { try { pi.send() } catch (e: Exception) { } }
            }
        }
        return out
    }

    private fun openOf(n: Notification, pkg: String): () -> Unit = {
        try {
            val pi: PendingIntent? = n.contentIntent
            if (pi != null) pi.send() else launch(pkg)
        } catch (e: Exception) {
            launch(pkg)
        }
    }

    private fun largeIcon(n: Notification): Bitmap? = try {
        n.getLargeIcon()?.loadDrawable(this)?.let { Util.toBitmap(it) }
    } catch (e: Exception) {
        null
    }

    private fun call(sbn: StatusBarNotification, n: Notification, title: String, text: String, chrono: Boolean) {
        val callType = n.extras.getInt("android.callType", 0)
        val incoming = callType == 1 || (callType == 0 && !chrono && n.fullScreenIntent != null)
        var actions = actionsOf(n)
        // Без root: Telecom API (разрешение «Телефон»); root, если включён, служит запасным путём
        val svc = this@DipNotificationListener
        if (incoming && actions.none { it.act == Act.ACCEPT }) {
            actions = actions + IslandAction(Act.ACCEPT, "answer") { Actions.answer(svc) }
        }
        if (actions.none { it.act == Act.DECLINE || it.act == Act.HANGUP }) {
            actions = actions + IslandAction(if (incoming) Act.DECLINE else Act.HANGUP, "end") { Actions.end(svc) }
        }
        Store.put(
            IslandItem(
                id = "call:${sbn.key}", kind = Kind.CALL, pkg = sbn.packageName,
                title = title.ifEmpty { "Вызов" }, subtitle = text,
                cover = largeIcon(n), appIcon = Util.appIcon(this, sbn.packageName),
                accent = 0xFF30D158, incoming = incoming,
                clockBase = if (chrono) n.`when` else 0L,
                actions = actions, open = openOf(n, sbn.packageName)
            )
        )
    }

    private fun nav(sbn: StatusBarNotification, n: Notification, title: String, text: String) {
        val all = (title + " " + text).lowercase()
        if (Regex("arriv|destination|прибы|пункт назначения").containsMatchIn(all)) {
            Store.alert(IslandAlert("nav:arrive", "Вы прибыли", "", 0xFFFFFFFF, Glyph.NAV, 0xFF30D158))
        } else if (Regex("reroute|new route|перестро|новый маршрут").containsMatchIn(all)) {
            Store.alert(IslandAlert("nav:reroute", "Новый маршрут", "", 0xFFFFFFFF, Glyph.NAV, 0xFF0A84FF))
        }
        // Google Maps: заголовок обычно «200 м», текст — манёвр; у других навигаторов наоборот
        val trail = if (title.length <= 12) title else text.take(10)
        val instr = if (title.length <= 12) text else title
        Store.put(
            IslandItem(
                id = "nav:${sbn.key}", kind = Kind.NAV, pkg = sbn.packageName,
                title = trail, subtitle = instr, trail = trail,
                cover = largeIcon(n), appIcon = Util.appIcon(this, sbn.packageName),
                accent = 0xFF0A84FF, actions = emptyList(), open = openOf(n, sbn.packageName)
            )
        )
    }

    private fun timer(
        sbn: StatusBarNotification, n: Notification, title: String, text: String,
        chrono: Boolean, countdown: Boolean
    ) {
        val acts = actionsOf(n)
        val paused = acts.any { it.label.lowercase().let { l -> l.contains("resume") || l.contains("продолж") || l.contains("start") } } &&
            acts.none { it.act == Act.PAUSE && it.label.lowercase().contains("pause") }
        Store.put(
            IslandItem(
                id = "timer:${sbn.key}", kind = Kind.TIMER, pkg = sbn.packageName,
                title = title.ifEmpty { "Таймер" }, subtitle = text, trail = if (chrono) "" else text.ifEmpty { title },
                appIcon = Util.appIcon(this, sbn.packageName), accent = 0xFFFF8C2B,
                clockBase = if (chrono) n.`when` else 0L, countdown = countdown, running = chrono && !paused,
                actions = acts, open = openOf(n, sbn.packageName)
            )
        )
    }

    private fun generic(sbn: StatusBarNotification, n: Notification, title: String, text: String) {
        if (title.isEmpty() && text.isEmpty()) return
        // Только уведомления со звуком или баннером
        val rm = newRanking()
        try {
            if (currentRanking.getRanking(sbn.key, rm) && rm.importance < android.app.NotificationManager.IMPORTANCE_DEFAULT) return
        } catch (e: Exception) {
        }
        Store.put(
            IslandItem(
                id = "n:${sbn.key}", kind = Kind.NOTIF, pkg = sbn.packageName,
                title = title.ifEmpty { Util.appLabel(this, sbn.packageName) }, subtitle = text,
                cover = largeIcon(n), appIcon = Util.appIcon(this, sbn.packageName),
                expiresAt = System.currentTimeMillis() + Prefs.notifMs + 400L,
                open = openOf(n, sbn.packageName)
            )
        )
    }

    private fun initialSkip(pkg: String): Boolean {
        if (pkg in Prefs.liveSet(Prefs.LIVE_OFF)) return true
        return false
    }

    /** Живые активности сторонних приложений: такси, доставка, загрузки, прогресс. */
    private fun live(sbn: StatusBarNotification, n: Notification, title: String, text: String, chrono: Boolean) {
        val pkg = sbn.packageName
        Prefs.noteSeen(pkg)
        val ex = n.extras
        val max = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
        val cur = ex.getInt(Notification.EXTRA_PROGRESS, 0)
        val indet = ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)
        val hasProgress = max > 0 && !indet
        val manual = pkg in Prefs.liveSet(Prefs.LIVE_ON)
        val p = pkg.lowercase()
        var glyph: Glyph? = null
        var label = ""
        var accent = 0xFF0A84FF
        val blob = (title + " " + text).lowercase()
        when {
            shareHints.any { p.contains(it) } || Regex("quick share|быстрая отправка|nearby share").containsMatchIn(blob) -> {
                glyph = Glyph.SHARE; label = "Отправка рядом"; accent = 0xFF0A84FF
            }
            Regex("\\bcast\\b|трансляц|screen shar|демонстрац").containsMatchIn(blob) -> {
                glyph = Glyph.CAST; label = "Трансляция"; accent = 0xFF5E5CE6
            }
            taxiHints.any { p.contains(it) } -> { glyph = Glyph.CAR; label = "Такси"; accent = 0xFFFFD60A }
            foodHints.any { p.contains(it) } -> { glyph = Glyph.BAG; label = "Доставка"; accent = 0xFF30D158 }
            trainHints.any { p.contains(it) } -> { glyph = Glyph.TICKET; label = "Поездка"; accent = 0xFF0A84FF }
            n.category == Notification.CATEGORY_PROGRESS && hasProgress -> {
                glyph = Glyph.DOWNLOAD; label = "Загрузка"; accent = 0xFF0A84FF
            }
        }
        val auto = Prefs.liveAuto && (glyph != null || hasProgress || chrono)
        if (!manual && !auto) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return
        if (title.isEmpty() && text.isEmpty()) return
        var progress = if (hasProgress) (cur.toFloat() / max).coerceIn(0f, 1f) else -1f
        // Такси и доставка: ETA, машина и номер, полоса пути по убыванию ETA
        val route = glyph == Glyph.CAR || glyph == Glyph.BAG
        var shownTitle = title.ifEmpty { Util.appLabel(this, pkg) }
        var shownSub = text
        var eta = ""
        if (route) {
            val full = (n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: text).toString()
            val sub = n.extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
            val info = Route.parse(title, full, sub)
            eta = info.etaText
            if (info.detail.isNotEmpty()) shownSub = info.detail
            if (progress < 0f && info.etaMin >= 0) {
                val start = synchronized(etaStart) {
                    val s = etaStart[sbn.key]
                    if (s == null || info.etaMin > s) { etaStart[sbn.key] = kotlin.math.max(info.etaMin, 1); kotlin.math.max(info.etaMin, 1) } else s
                }
                progress = (1f - info.etaMin.toFloat() / start).coerceIn(0.04f, 1f)
            }
        }
        Store.put(
            IslandItem(
                id = "live:${sbn.key}", kind = Kind.LIVE, pkg = pkg,
                title = shownTitle, subtitle = shownSub, trail = eta, style = if (route) 1 else 0,
                appIcon = Util.appIcon(this, pkg), cover = largeIcon(n),
                glyph = glyph, label = label, accent = accent, progress = progress,
                relevance = if (glyph == Glyph.CAR || glyph == Glyph.BAG || glyph == Glyph.TICKET) 60 else 30,
                actions = actionsOf(n), open = openOf(n, pkg)
            )
        )
    }

    /** Аналог Apple Pay / CarKey: уведомления кошельков показываются как карточка с иконкой. */
    private fun pay(sbn: StatusBarNotification, n: Notification, title: String, text: String) {
        if (title.isEmpty() && text.isEmpty()) return
        val blob = (title + " " + text).lowercase()
        val car = Regex("car key|vehicle|ключ|автомоб|авто ").containsMatchIn(blob)
        Store.put(
            IslandItem(
                id = "live:${sbn.key}", kind = Kind.LIVE, pkg = sbn.packageName,
                title = title.ifEmpty { Util.appLabel(this, sbn.packageName) }, subtitle = text,
                glyph = if (car) Glyph.CAR else Glyph.CARD, label = if (car) "Ключ от авто" else "Оплата",
                accent = if (car) 0xFF0A84FF else 0xFF30D158, relevance = 70,
                appIcon = Util.appIcon(this, sbn.packageName), open = openOf(n, sbn.packageName),
                expiresAt = System.currentTimeMillis() + 6_000L
            )
        )
        Store.setExpanded(true)
    }

    /** Аналог Find My: уведомления Google «Найти устройство» / трекер рядом. */
    private fun findMy(sbn: StatusBarNotification, n: Notification, title: String, text: String) {
        Store.alert(IslandAlert("findmy", title.ifEmpty { "Найти устройство" }.take(24), "", 0xFFFFFFFF, Glyph.FIND, 0xFF30D158))
    }

    private fun alarm(sbn: StatusBarNotification, n: Notification, title: String, text: String) {
        Store.put(
            IslandItem(
                id = "live:${sbn.key}", kind = Kind.LIVE, pkg = sbn.packageName,
                title = title.ifEmpty { "Будильник" }, subtitle = text, glyph = Glyph.ALARM,
                label = "Будильник", accent = 0xFFFF9F0A, relevance = 90,
                appIcon = Util.appIcon(this, sbn.packageName),
                actions = actionsOf(n), open = openOf(n, sbn.packageName),
                expiresAt = System.currentTimeMillis() + 60_000L
            )
        )
    }

    private fun recording(sbn: StatusBarNotification, n: Notification, title: String, text: String) {
        val screen = sbn.packageName.contains("screenrecord") || sbn.packageName.contains("screenrecorder")
        Store.put(
            IslandItem(
                id = "rec:${sbn.key}", kind = Kind.RECORDING, pkg = sbn.packageName,
                title = if (screen) "Запись экрана" else "Запись звука",
                subtitle = text.ifEmpty { title }, accent = 0xFFFF453A,
                appIcon = Util.appIcon(this, sbn.packageName),
                actions = actionsOf(n), open = openOf(n, sbn.packageName)
            )
        )
    }

    private fun newRanking(): NotificationListenerService.Ranking = NotificationListenerService.Ranking()
}
