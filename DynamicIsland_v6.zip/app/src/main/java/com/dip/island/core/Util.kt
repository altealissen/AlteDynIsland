package com.dip.island.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import kotlin.math.max
import kotlin.math.min

object Util {
    fun toBitmap(d: Drawable?, size: Int = 96): Bitmap? {
        if (d == null) return null
        if (d is BitmapDrawable && d.bitmap != null) {
            val b = d.bitmap
            return if (b.width <= size * 2) b else Bitmap.createScaledBitmap(b, size, size, true)
        }
        val w = if (d.intrinsicWidth > 0) d.intrinsicWidth else size
        val h = if (d.intrinsicHeight > 0) d.intrinsicHeight else size
        val k = size.toFloat() / max(w, h)
        val bw = max(1, (w * k).toInt())
        val bh = max(1, (h * k).toInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, bw, bh)
        d.draw(c)
        return bmp
    }

    fun appIcon(ctx: Context, pkg: String): Bitmap? = try {
        toBitmap(ctx.packageManager.getApplicationIcon(pkg), 96)
    } catch (e: Exception) {
        null
    }

    fun appLabel(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    /** Средний цвет обложки, подтянутый по яркости (для волны в острове). */
    fun dominant(b: Bitmap?): Long {
        if (b == null) return 0xFFFFFFFF
        return try {
            val s = Bitmap.createScaledBitmap(b, 8, 8, true)
            var r = 0L; var g = 0L; var bl = 0L; var n = 0
            for (x in 0 until 8) for (y in 0 until 8) {
                val p = s.getPixel(x, y)
                r += (p shr 16) and 0xFF; g += (p shr 8) and 0xFF; bl += p and 0xFF; n++
            }
            var rr = (r / n).toInt(); var gg = (g / n).toInt(); var bb = (bl / n).toInt()
            val peak = max(rr, max(gg, bb))
            if (peak in 1..199) {
                val k = 200f / peak
                rr = min(255, (rr * k).toInt()); gg = min(255, (gg * k).toInt()); bb = min(255, (bb * k).toInt())
            }
            if (peak == 0) return 0xFFFFFFFF
            (0xFFL shl 24) or (rr.toLong() shl 16) or (gg.toLong() shl 8) or bb.toLong()
        } catch (e: Exception) {
            0xFFFFFFFF
        }
    }

    fun clock(ms: Long): String {
        val s = max(0L, ms) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    fun mmss(ms: Long): String {
        val s = max(0L, ms) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }
}
