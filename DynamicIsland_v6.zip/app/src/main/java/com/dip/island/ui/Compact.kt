package com.dip.island.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import com.dip.island.core.C
import com.dip.island.core.Glyph
import com.dip.island.core.IslandAlert
import com.dip.island.core.IslandItem
import com.dip.island.core.Kind
import com.dip.island.core.Mode
import com.dip.island.core.Target
import com.dip.island.core.Tok
import com.dip.island.core.Util

@Composable
fun PtText(
    text: String, sizePt: Float, color: Color = C.White, weight: FontWeight = FontWeight.Medium,
    modifier: Modifier = Modifier, maxLines: Int = 1, tnum: Boolean = false
) {
    BasicText(
        text = text, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis,
        style = TextStyle(
            color = color, fontSize = sizePt.ptSp(), fontWeight = weight, fontFamily = FontFamily.SansSerif,
            fontFeatureSettings = if (tnum) "tnum" else null
        )
    )
}

/** Звуковая волна: столбики пульсируют, пока играет музыка. */
@Composable
fun Equalizer(count: Int, barPt: Float, pitchPt: Float, minPt: Float, maxPt: Float, color: Color, playing: Boolean) {
    val tr = rememberInfiniteTransition(label = "eq")
    val heights = (0 until count).map { i ->
        tr.animateFloat(
            initialValue = 0.25f, targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(380 + i * 83, easing = LinearEasing), RepeatMode.Reverse
            ),
            label = "bar$i"
        )
    }
    Row(
        Modifier.height(maxPt.pt()),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy((pitchPt - barPt).pt()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until count) {
            val f = if (playing) heights[i].value else 0.12f
            val h = minPt + (maxPt - minPt) * f
            Box(
                Modifier.width(barPt.pt()).height(h.pt()).clip(RoundedCornerShape(barPt.pt() / 2)).background(color)
            )
        }
    }
}

@Composable
fun ClockText(item: IslandItem, sizePt: Float, color: Color) {
    if (!item.running && item.trail.isNotEmpty()) {
        PtText(item.trail, sizePt, color, FontWeight.SemiBold, tnum = true)
        return
    }
    if (item.clockBase == 0L && item.trail.isNotEmpty()) {
        PtText(item.trail, sizePt, color, FontWeight.SemiBold, tnum = true)
        return
    }
    val now by tickWall(1000)
    val ms = if (item.countdown) item.clockBase - now else now - item.clockBase
    PtText(Util.clock(ms), sizePt, color, FontWeight.SemiBold, tnum = true)
}

@Composable
fun LeadIcon(i: IslandItem) {
    when (i.kind) {
        Kind.TIMER -> GlyphIcon(Glyph.STOPWATCH, Tok.ICON_TIMER.pt(), C.Timer)
        Kind.CALL -> GlyphIcon(Glyph.PHONE, Tok.ICON_TIMER.pt(), C.Green)
        Kind.NAV -> if (i.cover != null) BitmapBox(i.cover, Tok.ART.pt(), Tok.ART_R.pt())
        else GlyphIcon(Glyph.NAV, Tok.ART.pt(), C.Blue)
        Kind.MEDIA -> BitmapBox(i.cover, Tok.ART.pt(), Tok.ART_R.pt())
        Kind.RECORDING -> Unit
        Kind.LIVE -> if (i.glyph != null) GlyphIcon(i.glyph, Tok.ART.pt(), i.accent.color())
        else BitmapBox(i.appIcon ?: i.cover, Tok.ART.pt(), Tok.ART_R.pt())
        else -> BitmapBox(i.appIcon ?: i.cover, Tok.ART.pt(), Tok.ART_R.pt())
    }
}

@Composable
private fun Trail(i: IslandItem) {
    when (i.kind) {
        Kind.MEDIA -> Equalizer(5, 2.2f, 3.6f, 3f, 12f, i.accent.color(), i.playing)
        Kind.TIMER -> ClockText(i, 15f, C.Timer)
        Kind.CALL -> if (!i.incoming) {
            if (i.callState == 2) PtText("Удерж.", 15f, C.Timer, FontWeight.SemiBold)
            else if (i.callState == 1) PtText("Вызов…", 15f, C.Green, FontWeight.SemiBold)
            else ClockText(i, 15f, C.Green)
        }
        Kind.NAV -> PtText(i.trail, 15f, C.White, FontWeight.SemiBold)
        Kind.RECORDING -> Box(Modifier.size(14.5f.pt()).clip(CircleShape).background(i.accent.color()))
        Kind.LIVE -> if (i.trail.isNotEmpty()) PtText(i.trail, 15f, i.accent.color(), FontWeight.SemiBold, tnum = true)
        else if (i.progress >= 0f) ProgressRing(i.progress, 14f, i.accent.color())
        else Unit
        else -> Unit
    }
}

/** Compact и Split: контент слева и справа от зоны камеры. */
@Composable
fun CompactContent(t: Target) {
    val item = t.main ?: return
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.align(Alignment.CenterStart).padding(start = Tok.PAD.pt())) { LeadIcon(item) }
        if (t.mode != Mode.SPLIT) {
            val endPad = if (item.kind == Kind.TIMER || item.kind == Kind.CALL) Tok.CLOCK_PAD_R else Tok.PAD
            Box(Modifier.align(Alignment.CenterEnd).padding(end = endPad.pt())) { Trail(item) }
        }
    }
}

/** Alert: текст слева, значение и иконка справа (правило ширины см. Geo). */
@Composable
fun AlertContent(a: IslandAlert) {
    Box(Modifier.fillMaxSize()) {
        PtText(
            a.text, 15f, C.White, FontWeight.Medium,
            Modifier.align(Alignment.CenterStart).padding(start = 13.1f.pt())
        )
        Row(
            Modifier.align(Alignment.CenterEnd).padding(end = 14.06f.pt()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (a.value.isNotEmpty()) {
                PtText(a.value, 15f, a.valueColor.color(), FontWeight.SemiBold, tnum = true)
                Spacer(Modifier.width(7.8f.pt()))
            }
            if (a.batteryLevel >= 0) {
                GlyphIcon(Glyph.BATTERY, 37.5f.pt(), a.glyphColor.color(), a.batteryLevel)
            } else {
                GlyphIcon(a.glyph, 21f.pt(), a.glyphColor.color())
            }
        }
    }
}

/** Круговой индикатор прогресса (compact-режим живых активностей). */
@Composable
fun ProgressRing(progress: Float, sizePt: Float, color: Color) {
    androidx.compose.foundation.Canvas(Modifier.size(sizePt.pt())) {
        val w = size.minDimension * 0.16f
        val inset = w / 2
        val d = androidx.compose.ui.geometry.Size(size.width - w, size.height - w)
        drawArc(color.copy(alpha = 0.25f), 0f, 360f, false, androidx.compose.ui.geometry.Offset(inset, inset), d,
            style = androidx.compose.ui.graphics.drawscope.Stroke(w))
        drawArc(color, -90f, 360f * progress.coerceIn(0f, 1f), false, androidx.compose.ui.geometry.Offset(inset, inset), d,
            style = androidx.compose.ui.graphics.drawscope.Stroke(w, cap = androidx.compose.ui.graphics.StrokeCap.Round))
    }
}
