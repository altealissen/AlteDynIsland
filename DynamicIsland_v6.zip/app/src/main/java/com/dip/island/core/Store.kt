package com.dip.island.core

import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * Реестр активностей, очередь алертов и общее состояние UI.
 * Любой вызов из любого потока безопасен: изменения выполняются на главном потоке,
 * а исключения внутри не доходят до процесса.
 */
object Store {
    private const val TAG = "DipStore"
    private const val MAX_ITEMS = 12
    private const val MAX_QUEUE = 6

    val items = MutableStateFlow<Map<String, IslandItem>>(emptyMap())
    val alert = MutableStateFlow<IslandAlert?>(null)
    val expanded = MutableStateFlow(false)
    val pinned = MutableStateFlow<String?>(null)
    val env = MutableStateFlow(Env())
    val target = MutableStateFlow(Target())
    val listenerConnected = MutableStateFlow(false)
    val serviceRunning = MutableStateFlow(false)
    /** Режим настройки положения: остров показывает контурную капсулу. */
    val calibrate = MutableStateFlow(false)

    private val handler = Handler(Looper.getMainLooper())
    private val guard = CoroutineExceptionHandler { _, e -> Log.w(TAG, "coroutine", e) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate + guard)
    private val queue = ArrayDeque<IslandAlert>()
    private var alertJob: Job? = null
    private var autoCollapse: Job? = null

    private fun onMain(f: () -> Unit) {
        if (Looper.myLooper() === Looper.getMainLooper()) safe(f) else handler.post { safe(f) }
    }

    private fun safe(f: () -> Unit) {
        try { f() } catch (e: Exception) { Log.w(TAG, "store op", e) }
    }

    fun put(incoming: IslandItem) = onMain {
        val old = items.value[incoming.id]
        val item = if (old != null) incoming.copy(started = old.started, hidden = old.hidden) else incoming
        var next = items.value + (item.id to item)
        if (next.size > MAX_ITEMS) {
            // Лимит: выбрасываем самые старые уведомления, затем самые старые вообще
            val victim = next.values.filter { it.id != item.id }
                .sortedWith(compareBy<IslandItem> { if (it.kind == Kind.NOTIF) 0 else 1 }.thenBy { it.updated })
                .firstOrNull()
            if (victim != null) next = next - victim.id
        }
        items.value = next
        // Входящий звонок раскрывает остров автоматически
        if (item.kind == Kind.CALL && item.incoming && old?.incoming != true) {
            expanded.value = true
        }
        // Обновление живой активности кратко раскрывает остров (опция)
        if (Prefs.expandOnUpdate && old != null && (item.kind == Kind.LIVE || item.kind == Kind.TIMER) &&
            (old.title != item.title || old.subtitle != item.subtitle) && !expanded.value
        ) {
            expanded.value = true
            autoCollapse?.cancel()
            autoCollapse = scope.launch {
                delay(Prefs.notifMs)
                expanded.value = false
            }
        }
        // Уведомление показывается раскрытым и сворачивается само
        if (item.kind == Kind.NOTIF && old == null) {
            expanded.value = true
            autoCollapse?.cancel()
            autoCollapse = scope.launch {
                delay(Prefs.notifMs)
                if (items.value[item.id]?.kind == Kind.NOTIF) expanded.value = false
            }
        }
    }

    fun remove(id: String) = onMain {
        val removed = items.value[id]
        if (removed != null) {
            items.value = items.value - id
            if (pinned.value == id) pinned.value = null
            if (items.value.isEmpty() || removed.incoming) expanded.value = false
        }
    }

    fun removeWhere(pred: (IslandItem) -> Boolean) = onMain {
        items.value.values.filter(pred).forEach { remove(it.id) }
    }

    fun purge(now: Long) {
        removeWhere { it.expiresAt in 1..now }
    }

    fun clearAll() = onMain {
        alertJob?.cancel(); autoCollapse?.cancel()
        alertJob = null; autoCollapse = null
        items.value = emptyMap(); alert.value = null; expanded.value = false; pinned.value = null
        queue.clear()
    }

    fun alert(a: IslandAlert) = onMain {
        if (alert.value == a) return@onMain
        if (alert.value?.id == a.id) {
            alert.value = a
            return@onMain
        }
        queue.removeAll { it.id == a.id }
        queue.addLast(a)
        while (queue.size > MAX_QUEUE) queue.removeFirst()
        if (alertJob?.isActive == true) return@onMain
        alertJob = scope.launch {
            try {
                while (queue.isNotEmpty()) {
                    val next = queue.removeFirst()
                    alert.value = next
                    delay(Prefs.alertMs)
                    alert.value = null
                    delay(380)
                }
            } finally {
                // Даже при отмене или ошибке алерт не должен «залипнуть»
                alert.value = null
            }
        }
    }

    /** Переключение прикреплённой активности (тап по пузырю, свайп по острову). */
    fun cycle() = onMain {
        val order = Geo.order(items.value.values, pinned.value)
        if (order.size >= 2) pinned.value = order[1].id
    }

    fun select(id: String) = onMain { pinned.value = id }

    fun setExpanded(v: Boolean) = onMain { expanded.value = v }

    /** DIP-GST-006/007: скрыть активность до конца сессии / вернуть все скрытые. */
    fun hide(id: String) = onMain {
        items.value[id]?.let { items.value = items.value + (id to it.copy(hidden = true)) }
        if (pinned.value == id) pinned.value = null
        expanded.value = false
    }

    fun restoreHidden() = onMain {
        items.value = items.value.mapValues { it.value.copy(hidden = false) }
    }
}
