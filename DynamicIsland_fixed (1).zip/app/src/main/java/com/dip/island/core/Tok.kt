package com.dip.island.core

import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.Color

/**
 * Design tokens. Все значения в pt iOS (1 pt = 0.16565 мм); физический размер на Android
 * получается умножением на DP_PER_PT. Источник: DIP_20 (измерения iPhone 16 Pro) и HIG.
 */
object Tok {
    const val DP_PER_PT = 1.0435f

    // Геометрия капсулы и зоны камеры
    const val CAM_W = 125.48f
    const val CAM_H = 36.81f
    const val TOP = 14.06f
    const val CAM_GAP = 18.9f

    // Expanded
    const val EXP_W = 374.24f
    const val H_MEDIA = 204.71f
    const val H_TIMER = 88.33f
    const val H_CARD = 100f
    const val H_CALL = 104f
    const val R_EXP = 44f

    // Split
    const val SPLIT_GAP = 7.84f
    const val BUBBLE = 36.83f

    // Суперэллипс
    const val N_PILL = 2.65f
    const val N_EXP = 3.1f

    // Compact
    const val PAD = 8.8f
    const val ART = 23.6f
    const val ART_R = 6.11f
    const val ICON_TIMER = 21f
    const val CONTENT_GAP = 3f

    // Запас вокруг острова для окна-оверлея
    const val WIN_MARGIN = 16f

    // Время
    const val LONG_PRESS_INFLATE = 1.10f

    fun spr(response: Float, zeta: Float): SpringSpec<Float> {
        val w = 2.0 * Math.PI / response
        return spring(dampingRatio = zeta, stiffness = (w * w).toFloat())
    }

    // Пружины: response (с), ζ  (DIP_20 §7.1)
    val APPEAR = spr(0.459f, 0.847f)
    val DISAPPEAR = spr(0.528f, 0.758f)
    val EXPAND_W = spr(0.522f, 0.817f)
    val EXPAND_H = spr(0.527f, 0.815f)
    val COLLAPSE_W = spr(0.374f, 0.742f)
    val COLLAPSE_H = spr(0.493f, 0.869f)
    val SPLIT_ISLAND = spr(0.524f, 0.509f)
    val BUBBLE_SPR = spr(0.487f, 0.696f)
    val SPLIT_BACK = spr(0.477f, 0.868f)
    val ALERT_IN = spr(0.536f, 0.810f)
    val ALERT_OUT = spr(0.495f, 0.562f)
    val PRESS = spr(0.471f, 0.829f)

    // Контент внутри острова (DIP_20 §7.3)
    const val CONTENT_IN_DELAY = 56
    const val CONTENT_IN_MS = 262
    const val CONTENT_OUT_DELAY = 36
    const val CONTENT_OUT_MS = 105
    const val CONTENT_BLUR = 15.1f
    const val CONTENT_SCALE = 0.75f
}

object C {
    val Black = Color(0xFF000000)
    val White = Color(0xFFFFFFFF)
    val Secondary = Color(0xFF8F8F90)
    val TimeText = Color(0xFF919092)
    val ProgFill = Color(0xFF919098)
    val ProgTrack = Color(0xFF212022)
    val Timer = Color(0xFFFF8C2B)
    val Charge = Color(0xFF56FE36)
    val ChargeText = Color(0xFF52FFA9)
    val Rec = Color(0xFFD3382A)
    val Mic = Color(0xFFFF9F0A)
    val Red = Color(0xFFFF453A)
    val Green = Color(0xFF30D158)
    val Yellow = Color(0xFFFFD60A)
    val Purple = Color(0xFF5E5CE6)
    val Blue = Color(0xFF0A84FF)
    val BtnGray = Color(0xFF2C2C2E)
}
