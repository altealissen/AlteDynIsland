package com.dip.island.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Пустой сервис специальных возможностей. Нужен только ради окна типа TYPE_ACCESSIBILITY_OVERLAY:
 * оно лежит выше строки состояния и принимает касания там, где обычный оверлей их не получает
 * (в этой зоне жест вниз открывает шторку). Содержимое экрана не читается.
 */
class DipAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: DipAccessibilityService? = null
            private set

        const val COMPONENT = "com.dip.island/com.dip.island.service.DipAccessibilityService"

        fun isEnabled(ctx: android.content.Context): Boolean {
            if (instance != null) return true
            return try {
                val s = android.provider.Settings.Secure.getString(
                    ctx.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: ""
                s.split(':').any { it.endsWith("DipAccessibilityService") }
            } catch (e: Exception) { false }
        }
    }
}
