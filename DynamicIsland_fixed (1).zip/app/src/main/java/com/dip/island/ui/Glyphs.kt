package com.dip.island.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import com.dip.island.core.Glyph

/** Иконки, нарисованные в сетке 24×24 (чтобы не тянуть библиотеку иконок). */
@Composable
fun GlyphIcon(g: Glyph, size: Dp, color: Color, level: Int = -1, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val k = this.size.minDimension / 24f
        drawGlyph(g, color, k, level)
    }
}

private fun DrawScope.drawGlyph(g: Glyph, c: Color, k: Float, level: Int) {
    fun o(x: Float, y: Float) = Offset(x * k, y * k)
    fun sz(w: Float, h: Float) = Size(w * k, h * k)
    val sw = 2f * k
    val round = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)

    when (g) {
        Glyph.PLAY -> drawPath(Path().apply {
            moveTo(7f * k, 4f * k); lineTo(20f * k, 12f * k); lineTo(7f * k, 20f * k); close()
        }, c)
        Glyph.PAUSE -> {
            drawRoundRect(c, o(6f, 4f), sz(4f, 16f), CornerRadius(1.2f * k))
            drawRoundRect(c, o(14f, 4f), sz(4f, 16f), CornerRadius(1.2f * k))
        }
        Glyph.NEXT -> {
            drawPath(Path().apply {
                moveTo(4f * k, 5f * k); lineTo(14f * k, 12f * k); lineTo(4f * k, 19f * k); close()
            }, c)
            drawRoundRect(c, o(15f, 5f), sz(3.6f, 14f), CornerRadius(1.2f * k))
        }
        Glyph.PREV -> {
            drawPath(Path().apply {
                moveTo(20f * k, 5f * k); lineTo(10f * k, 12f * k); lineTo(20f * k, 19f * k); close()
            }, c)
            drawRoundRect(c, o(5.4f, 5f), sz(3.6f, 14f), CornerRadius(1.2f * k))
        }
        Glyph.PHONE, Glyph.PHONE_DOWN -> {
            val deg = if (g == Glyph.PHONE) 0f else 135f
            rotate(deg, pivot = o(12f, 12f)) {
                val p = Path().apply {
                    moveTo(6f * k, 5.5f * k)
                    quadraticBezierTo(5.5f * k, 17.5f * k, 18.5f * k, 18f * k)
                }
                drawPath(p, c, style = Stroke(width = 4.2f * k, cap = StrokeCap.Round))
                drawCircle(c, 2.4f * k, o(6.2f, 5.2f))
                drawCircle(c, 2.4f * k, o(18.6f, 18.2f))
            }
        }
        Glyph.CLOSE -> {
            drawLine(c, o(6f, 6f), o(18f, 18f), strokeWidth = 2.4f * k, cap = StrokeCap.Round)
            drawLine(c, o(18f, 6f), o(6f, 18f), strokeWidth = 2.4f * k, cap = StrokeCap.Round)
        }
        Glyph.BATTERY, Glyph.SAVER -> {
            drawRoundRect(c, o(1.5f, 6.5f), sz(19f, 11f), CornerRadius(3.2f * k), style = Stroke(1.5f * k))
            drawRoundRect(c, o(21f, 10f), sz(1.8f, 4f), CornerRadius(0.9f * k))
            val l = if (level in 0..100) level / 100f else 1f
            drawRoundRect(c, o(3.2f, 8.2f), sz(15.6f * l, 7.6f), CornerRadius(1.8f * k))
        }
        Glyph.BOLT -> drawPath(Path().apply {
            moveTo(13.5f * k, 2f * k); lineTo(5f * k, 13.5f * k); lineTo(11f * k, 13.5f * k)
            lineTo(10f * k, 22f * k); lineTo(19f * k, 10f * k); lineTo(13f * k, 10f * k); close()
        }, c)
        Glyph.BELL, Glyph.BELL_OFF -> {
            val bell = Path().apply {
                moveTo(5f * k, 17f * k); lineTo(5f * k, 11f * k)
                cubicTo(5f * k, 6.5f * k, 8f * k, 4f * k, 12f * k, 4f * k)
                cubicTo(16f * k, 4f * k, 19f * k, 6.5f * k, 19f * k, 11f * k)
                lineTo(19f * k, 17f * k); lineTo(21f * k, 19f * k); lineTo(3f * k, 19f * k); close()
            }
            drawPath(bell, c)
            drawArc(c, 0f, 180f, true, o(9.5f, 18.5f), sz(5f, 4.5f))
            if (g == Glyph.BELL_OFF) {
                drawLine(Color.Black, o(3.2f, 2.2f), o(21f, 21f), strokeWidth = 4.4f * k, cap = StrokeCap.Round)
                drawLine(c, o(3.6f, 3.6f), o(20.4f, 20.4f), strokeWidth = 2f * k, cap = StrokeCap.Round)
            }
        }
        Glyph.HEADPHONES -> {
            drawArc(c, 180f, 180f, false, o(3.5f, 3.5f), sz(17f, 17f), style = Stroke(2f * k, cap = StrokeCap.Round))
            drawRoundRect(c, o(2.5f, 12.5f), sz(5f, 8f), CornerRadius(2f * k))
            drawRoundRect(c, o(16.5f, 12.5f), sz(5f, 8f), CornerRadius(2f * k))
        }
        Glyph.AIRPLANE -> drawPath(Path().apply {
            moveTo(21f * k, 16f * k); lineTo(21f * k, 14f * k); lineTo(13f * k, 9f * k); lineTo(13f * k, 3.5f * k)
            cubicTo(13f * k, 2.7f * k, 12.3f * k, 2f * k, 11.5f * k, 2f * k)
            cubicTo(10.7f * k, 2f * k, 10f * k, 2.7f * k, 10f * k, 3.5f * k)
            lineTo(10f * k, 9f * k); lineTo(2f * k, 14f * k); lineTo(2f * k, 16f * k)
            lineTo(10f * k, 13.5f * k); lineTo(10f * k, 19f * k); lineTo(8f * k, 20.5f * k)
            lineTo(8f * k, 22f * k); lineTo(11.5f * k, 21f * k); lineTo(15f * k, 22f * k)
            lineTo(15f * k, 20.5f * k); lineTo(13f * k, 19f * k); lineTo(13f * k, 13.5f * k); close()
        }, c)
        Glyph.MOON -> {
            val a = Path().apply { addOval(androidx.compose.ui.geometry.Rect(o(3f, 3f), sz(18f, 18f))) }
            val b = Path().apply { addOval(androidx.compose.ui.geometry.Rect(o(9f, 0.5f), sz(16f, 16f))) }
            drawPath(Path.combine(PathOperation.Difference, a, b), c)
        }
        Glyph.FLASH -> {
            drawRoundRect(c, o(8f, 2f), sz(8f, 4f), CornerRadius(1f * k))
            drawPath(Path().apply {
                moveTo(8f * k, 7f * k); lineTo(16f * k, 7f * k); lineTo(15f * k, 11f * k)
                lineTo(15f * k, 22f * k); lineTo(9f * k, 22f * k); lineTo(9f * k, 11f * k); close()
            }, c)
        }
        Glyph.MIC -> {
            drawRoundRect(c, o(8.5f, 2.5f), sz(7f, 12f), CornerRadius(3.5f * k))
            drawArc(c, 0f, 180f, false, o(5f, 6.5f), sz(14f, 12f), style = Stroke(1.8f * k, cap = StrokeCap.Round))
            drawLine(c, o(12f, 18.5f), o(12f, 21.5f), strokeWidth = 1.8f * k, cap = StrokeCap.Round)
        }
        Glyph.BLUETOOTH -> {
            val p = Path().apply {
                moveTo(6f * k, 7.5f * k); lineTo(17f * k, 16.5f * k); lineTo(12f * k, 21f * k)
                lineTo(12f * k, 3f * k); lineTo(17f * k, 7.5f * k); lineTo(6f * k, 16.5f * k)
            }
            drawPath(p, c, style = round)
        }
        Glyph.SPEAKER -> {
            drawPath(Path().apply {
                moveTo(3f * k, 9f * k); lineTo(7f * k, 9f * k); lineTo(12f * k, 4.5f * k)
                lineTo(12f * k, 19.5f * k); lineTo(7f * k, 15f * k); lineTo(3f * k, 15f * k); close()
            }, c)
            drawArc(c, -50f, 100f, false, o(11f, 7f), sz(8f, 10f), style = Stroke(1.8f * k, cap = StrokeCap.Round))
            drawArc(c, -50f, 100f, false, o(8f, 3.5f), sz(15f, 17f), style = Stroke(1.8f * k, cap = StrokeCap.Round))
        }
        Glyph.STOPWATCH -> {
            drawCircle(c, 8f * k, o(12f, 13.5f), style = Stroke(2f * k))
            drawLine(c, o(12f, 13.5f), o(12f, 9f), strokeWidth = 2f * k, cap = StrokeCap.Round)
            drawLine(c, o(9.5f, 2.5f), o(14.5f, 2.5f), strokeWidth = 2f * k, cap = StrokeCap.Round)
        }
        Glyph.NAV -> drawPath(Path().apply {
            moveTo(12f * k, 2.5f * k); lineTo(19.5f * k, 20.5f * k); lineTo(12f * k, 16.5f * k)
            lineTo(4.5f * k, 20.5f * k); close()
        }, c)
    }
}
