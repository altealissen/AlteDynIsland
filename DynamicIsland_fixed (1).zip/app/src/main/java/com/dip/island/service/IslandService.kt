package com.dip.island.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.dip.island.MainActivity
import com.dip.island.core.Env
import com.dip.island.core.Geo
import com.dip.island.core.Mode
import com.dip.island.core.Prefs
import com.dip.island.core.Root
import com.dip.island.core.Store
import com.dip.island.core.Target
import com.dip.island.core.Tok
import com.dip.island.ui.IslandRoot
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class IslandService : Service() {

    private class Owner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val lr = LifecycleRegistry(this)
        private val ssc = SavedStateRegistryController.create(this)
        private val vms = ViewModelStore()

        init {
            ssc.performAttach()
            ssc.performRestore(null)
            lr.currentState = Lifecycle.State.CREATED
        }

        override val lifecycle: Lifecycle get() = lr
        override val savedStateRegistry: SavedStateRegistry get() = ssc.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = vms
        fun resume() { lr.currentState = Lifecycle.State.RESUMED }
        fun destroy() { lr.currentState = Lifecycle.State.DESTROYED; vms.clear() }
    }

    // Любая необработанная ошибка корутины логируется и не роняет процесс
    private val guard = CoroutineExceptionHandler { _, e -> Log.w(TAG, "coroutine error", e) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + guard)
    private var wm: WindowManager? = null
    private var view: ComposeView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var owner: Owner? = null
    private var events: SystemEvents? = null
    private var shrinkJob: Job? = null
    private var curW = 0
    private var curH = 0
    private var attachedAt = 0L
    private var headsApplied = false
    private var created = false
    private var usingA11y = false

    private var cutoutKnown = false
    private var cutoutCenterY = 0f
    private var cutoutCenterX = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        try {
            startAsForeground()
        } catch (e: Exception) {
            Log.w(TAG, "foreground failed", e)
            stopSelf(); return
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (!Settings.canDrawOverlays(this) && DipAccessibilityService.instance == null) {
            stopSelf(); return
        }
        buildEnv()
        if (!attachOverlay()) {
            stopSelf(); return
        }
        created = true
        Store.serviceRunning.value = true
        events = SystemEvents(this).also { it.register() }

        scope.launch {
            var lastHeads: Boolean? = null
            Prefs.rev.collect {
                safely { buildEnv() }
                // Системные баннеры трогаем только при реальном изменении настройки
                val want = Prefs.rootMode && Prefs.suppressHeadsUp
                if (want != lastHeads) {
                    val first = lastHeads == null
                    lastHeads = want
                    if (!(first && !want)) applyHeadsUp(want)
                }
            }
        }
        scope.launch { Store.calibrate.collect { safely { buildEnv() } } }
        scope.launch {
            combine(Store.items, Store.alert, Store.expanded, Store.pinned, Store.env) { items, alert, exp, pin, env ->
                try {
                    Geo.compute(items, alert, exp, pin, env, env.idle || env.calib)
                } catch (e: Exception) {
                    Log.w(TAG, "geo failed", e)
                    Store.target.value
                }
            }.collect { t ->
                Store.target.value = t
                safely { applyWindow(t) }
            }
        }
        scope.launch {
            var n = 0
            while (true) {
                delay(500)
                Store.purge(System.currentTimeMillis())
                if (++n % 4 == 0) safely { ensureAttached() }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Поворот или смена плотности: заново определяем вырез и геометрию
        cutoutKnown = false
        safely { buildEnv() }
        view?.postDelayed({ safely { detectCutout() } }, 300)
    }

    override fun onDestroy() {
        Store.serviceRunning.value = false
        safely { events?.unregister() }
        scope.cancel()
        safely { detachOverlay() }
        owner?.destroy(); owner = null
        if (created) Store.clearAll()
        if (headsApplied) {
            val app = applicationContext
            Thread { Root.setHeadsUp(app, false) }.start()
        }
        super.onDestroy()
    }

    private inline fun safely(block: () -> Unit) {
        try { block() } catch (e: Exception) { Log.w(TAG, "guarded", e) }
    }

    // ---------------------------------------------------------------- foreground

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel("dip_service", "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
        val pi = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "dip_service")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Dynamic Island работает")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun applyHeadsUp(hide: Boolean) {
        headsApplied = hide
        val app = applicationContext
        Thread { Root.setHeadsUp(app, hide) }.start()
    }

    // ---------------------------------------------------------------- environment

    private fun buildEnv() {
        val dm = resources.displayMetrics
        val density = dm.density
        val sw = dm.widthPixels
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val screenWdp = sw / density
        val maxPt = (screenWdp - 12f) / Tok.EXP_W
        val dpPerPt = min(Tok.DP_PER_PT * Prefs.scale, maxPt)
        val unit = dpPerPt * density

        val camW = (Tok.CAM_W + Prefs.adjW).coerceIn(60f, 220f)
        val camH = (Tok.CAM_H + Prefs.adjH).coerceIn(20f, 70f)

        val baseTop = if (cutoutKnown) cutoutCenterY - camH * unit / 2f else Tok.TOP * unit
        val cx = if (cutoutKnown) cutoutCenterX else sw / 2f
        val autoShift = if (abs(cx - sw / 2f) < sw * 0.12f) 0f else (cx - sw / 2f)
        val maxShift = sw * 0.45f
        val shift = (autoShift + Prefs.offX * density).coerceIn(-maxShift, maxShift).roundToInt()
        val top = max(0f, baseTop + Prefs.offY * density)

        val env = Env(
            density = density, screenWpx = sw, topPx = top, shiftPx = shift, dpPerPt = dpPerPt,
            keyline = Prefs.keyline, longPressMs = Prefs.longPressMs, rev = Prefs.rev.value,
            camW = camW, camH = camH, hidden = landscape, calib = Store.calibrate.value, fx = Prefs.blurFx, idle = Prefs.showIdle
        )
        if (env != Store.env.value) Store.env.value = env
    }

    /** Центр выреза камеры в координатах экрана. Любая ошибка — остаёмся на значениях по умолчанию. */
    private fun detectCutout() {
        if (Build.VERSION.SDK_INT < 28) return
        var r: Rect? = null
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                r = wm?.currentWindowMetrics?.windowInsets?.displayCutout?.boundingRects?.firstOrNull { it.top <= 2 }
            } catch (e: Exception) { }
        }
        if (r == null) {
            val v = view ?: return
            val cut = v.rootWindowInsets?.displayCutout ?: return
            val found = cut.boundingRects.firstOrNull { it.top <= 2 } ?: return
            // В insets окна координаты относительны окна, а не экрана
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            r = Rect(found).also { it.offset(loc[0], loc[1]) }
        }
        val rect = r ?: return
        if (rect.width() <= 0 || rect.height() <= 0) return
        val cy = (rect.top + rect.bottom) / 2f
        val cx = (rect.left + rect.right) / 2f
        // Идемпотентно: без изменений ничего не пересчитываем, иначе insets-цикл мерцает
        if (cutoutKnown && abs(cy - cutoutCenterY) < 0.5f && abs(cx - cutoutCenterX) < 0.5f) return
        cutoutKnown = true
        cutoutCenterY = cy
        cutoutCenterX = cx
        buildEnv()
    }

    // ---------------------------------------------------------------- window

    private fun attachOverlay(): Boolean {
        // С включённой «специальной возможностью» окно лежит выше строки состояния и ловит касания
        // в её зоне; иначе обычный оверлей, где жест вниз у верхнего края открывает шторку
        val a11y = DipAccessibilityService.instance
        val baseWm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val manager = if (a11y != null) {
            (a11y.getSystemService(Context.WINDOW_SERVICE) as? WindowManager) ?: baseWm
        } else baseWm
        val a11yType = a11y != null && manager !== baseWm
        if (!a11yType && !Settings.canDrawOverlays(this)) return false
        wm = manager
        val o = Owner().also { owner = it }
        o.resume()
        val cv = ComposeView(this)
        cv.setViewTreeLifecycleOwner(o)
        cv.setViewTreeSavedStateRegistryOwner(o)
        cv.setViewTreeViewModelStoreOwner(o)
        cv.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        cv.setContent { IslandRoot() }
        cv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && Store.expanded.value) Store.setExpanded(false)
            false
        }
        cv.setOnApplyWindowInsetsListener { v: View, insets ->
            safely { detectCutout() }
            insets
        }
        val p = WindowManager.LayoutParams(
            1, 1,
            if (a11yType) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.x = Store.env.value.shiftPx
        p.y = 0
        p.title = "DynamicIsland"
        if (Build.VERSION.SDK_INT >= 30) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return try {
            manager.addView(cv, p)
            view = cv
            lp = p
            usingA11y = a11y != null
            curW = 1; curH = 1
            attachedAt = SystemClock.elapsedRealtime()
            cv.postDelayed({ safely { detectCutout() } }, 400)
            true
        } catch (e: Exception) {
            // Нет разрешения на наложение или окно отклонено системой
            Log.w(TAG, "addView failed", e)
            owner?.destroy(); owner = null
            false
        }
    }

    private fun detachOverlay() {
        shrinkJob?.cancel()
        val v = view
        view = null
        lp = null
        if (v != null) {
            try { v.disposeComposition() } catch (e: Exception) { }
            try { wm?.removeView(v) } catch (e: Exception) { }
        }
    }

    /** Сторожевой таймер: если система сняла окно, пересоздаём его. */
    private fun ensureAttached() {
        val v = view
        // Если включили/выключили сервис специальных возможностей, переносим окно на подходящий тип
        val wantA11y = DipAccessibilityService.instance != null
        val typeOk = wantA11y == usingA11y
        if (v != null && typeOk && (v.isAttachedToWindow || SystemClock.elapsedRealtime() - attachedAt < 3000)) return
        if (!Settings.canDrawOverlays(this) && !wantA11y) {
            stopSelf(); return
        }
        detachOverlay()
        owner?.destroy(); owner = null
        if (!attachOverlay()) {
            stopSelf(); return
        }
        applyWindow(Store.target.value)
    }

    /** Окно подгоняется под блок острова, чтобы не перехватывать касания шторки. */
    private fun applyWindow(t: Target) {
        val v = view ?: return
        val p = lp ?: return
        val manager = wm ?: return
        val env = Store.env.value
        val unit = env.dpPerPt * env.density
        val hidden = t.mode == Mode.HIDDEN
        val needW = if (hidden) 1 else
            ((2f * max(-t.blockLeft, t.blockRight) + 2f * Tok.WIN_MARGIN) * unit).roundToInt()
        val needH = if (hidden) 1 else (env.topPx + (t.h + Tok.WIN_MARGIN) * unit).roundToInt()
        val w = min(needW, env.screenWpx).coerceAtLeast(1)
        val h = needH.coerceAtLeast(1)

        fun commit(width: Int, height: Int, touchable: Boolean) {
            val flags = if (touchable) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            if (width == p.width && height == p.height && env.shiftPx == p.x && flags == p.flags) return
            curW = width; curH = height
            p.width = width; p.height = height
            p.x = env.shiftPx
            p.flags = flags
            try { manager.updateViewLayout(v, p) } catch (e: Exception) { Log.w(TAG, "updateViewLayout", e) }
        }

        shrinkJob?.cancel()
        if (w >= curW && h >= curH) {
            commit(w, h, !hidden)
        } else {
            // Растём сразу, сжимаемся только после окончания пружин
            commit(max(w, curW), max(h, curH), !hidden)
            shrinkJob = scope.launch {
                delay(900)
                safely { commit(w, h, !hidden) }
            }
        }
    }

    private companion object {
        const val TAG = "DipService"
    }
}
