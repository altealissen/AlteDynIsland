package com.dip.island.core

import android.os.SystemClock

/** Тестовые события для проверки острова без реальных источников. */
object Demo {
    fun music() {
        val base = IslandItem(
            id = "demo:media", kind = Kind.MEDIA, pkg = "demo", title = "Blinding Lights",
            subtitle = "The Weeknd", playing = true, positionMs = 83_000, durationMs = 200_000,
            stampElapsed = SystemClock.elapsedRealtime(), accent = 0xFFFF7A59
        )
        Store.put(withActions(base))
    }

    private fun withActions(i: IslandItem): IslandItem = i.copy(
        seek = { ms ->
            Store.items.value["demo:media"]?.let { cur ->
                Store.put(withActions(cur.copy(positionMs = ms, stampElapsed = SystemClock.elapsedRealtime(), actions = emptyList())))
            }
        },
        actions = listOf(
            IslandAction(Act.PREV, "prev") { },
            IslandAction(if (i.playing) Act.PAUSE else Act.PLAY, "play") {
                val now = SystemClock.elapsedRealtime()
                val pos = if (i.playing) i.positionMs + ((now - i.stampElapsed) * i.speed).toLong() else i.positionMs
                Store.put(withActions(i.copy(playing = !i.playing, positionMs = pos, stampElapsed = now, actions = emptyList())))
            },
            IslandAction(Act.NEXT, "next") { }
        )
    )

    fun timer() = Store.put(
        IslandItem(
            id = "demo:timer", kind = Kind.TIMER, pkg = "demo", title = "Таймер", accent = 0xFFFF8C2B,
            clockBase = System.currentTimeMillis() + 10 * 60_000L, countdown = true,
            actions = listOf(IslandAction(Act.STOP, "stop") { Store.remove("demo:timer") })
        )
    )

    fun call() = Store.put(
        IslandItem(
            id = "demo:call", kind = Kind.CALL, pkg = "demo", title = "Анна Смирнова", incoming = true,
            subtitle = "мобильный",
            actions = listOf(
                IslandAction(Act.ACCEPT, "answer") {
                    val old = Store.items.value["demo:call"] ?: return@IslandAction
                    Store.put(old.copy(incoming = false, clockBase = System.currentTimeMillis(), updated = System.currentTimeMillis()))
                    Store.expanded.value = false
                },
                IslandAction(Act.DECLINE, "decline") { Store.remove("demo:call") },
                IslandAction(Act.HANGUP, "end") { Store.remove("demo:call") }
            )
        )
    )

    fun notification() = Store.put(
        IslandItem(
            id = "demo:notif:" + System.currentTimeMillis(), kind = Kind.NOTIF, pkg = "demo",
            title = "Мария", subtitle = "Привет! Ты уже видел новую версию?",
            expiresAt = System.currentTimeMillis() + Prefs.notifMs + 400L
        )
    )

    fun charging() = Store.alert(
        IslandAlert("charge", "Зарядка", "98 %", 0xFF52FFA9, Glyph.BATTERY, 0xFF56FE36, 98)
    )

    fun silent() = Store.alert(IslandAlert("ringer", "Без звука", "", 0xFFFFFFFF, Glyph.BELL_OFF, 0xFFFF453A))

    fun clear() = Store.clearAll()
}
