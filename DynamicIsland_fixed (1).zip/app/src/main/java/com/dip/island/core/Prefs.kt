package com.dip.island.core

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

object Prefs {
    private lateinit var sp: SharedPreferences
    val rev = MutableStateFlow(0)

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("dip", Context.MODE_PRIVATE)
        }
    }

    private fun ready() = ::sp.isInitialized
    private fun bump() = rev.update { it + 1 }

    private fun bool(key: String, def: Boolean) = if (ready()) sp.getBoolean(key, def) else def
    private fun putBool(key: String, v: Boolean) {
        if (!ready()) return
        sp.edit().putBoolean(key, v).apply(); bump()
    }

    private fun flt(key: String, def: Float) = if (ready()) sp.getFloat(key, def) else def
    private fun putFlt(key: String, v: Float) {
        if (!ready()) return
        sp.edit().putFloat(key, v).apply(); bump()
    }

    private fun lng(key: String, def: Long) = if (ready()) sp.getLong(key, def) else def
    private fun putLng(key: String, v: Long) {
        if (!ready()) return
        sp.edit().putLong(key, v).apply(); bump()
    }

    var enabled: Boolean
        get() = bool("enabled", true); set(v) = putBool("enabled", v)
    var showIdle: Boolean
        get() = bool("showIdle", false); set(v) = putBool("showIdle", v)
    var keyline: Boolean
        get() = bool("keyline", true); set(v) = putBool("keyline", v)
    var blurFx: Boolean
        get() = bool("blurFx", true); set(v) = putBool("blurFx", v)
    var scale: Float
        get() = flt("scale", 1f).coerceIn(0.7f, 1.3f); set(v) = putFlt("scale", v.coerceIn(0.7f, 1.3f))
    var longPressMs: Long
        get() = lng("longPressMs", 350L); set(v) = putLng("longPressMs", v)
    var alertMs: Long
        get() = lng("alertMs", 3000L); set(v) = putLng("alertMs", v)
    var notifMs: Long
        get() = lng("notifMs", 5000L); set(v) = putLng("notifMs", v)

    // Ручное положение (всегда добавляется к автоопределению выреза камеры)
    const val OFF_X_MAX = 150f
    const val OFF_Y_MIN = -30f
    const val OFF_Y_MAX = 90f
    const val ADJ_W_MIN = -40f
    const val ADJ_W_MAX = 60f
    const val ADJ_H_MIN = -10f
    const val ADJ_H_MAX = 25f

    /** Сдвиг по горизонтали, dp (вправо положительный). */
    var offX: Float
        get() = flt("offX", 0f).coerceIn(-OFF_X_MAX, OFF_X_MAX); set(v) = putFlt("offX", v.coerceIn(-OFF_X_MAX, OFF_X_MAX))
    /** Сдвиг по вертикали, dp (вниз положительный). */
    var offY: Float
        get() = flt("offY", 0f).coerceIn(OFF_Y_MIN, OFF_Y_MAX); set(v) = putFlt("offY", v.coerceIn(OFF_Y_MIN, OFF_Y_MAX))
    /** Добавка к ширине капсулы, pt. */
    var adjW: Float
        get() = flt("adjW", 0f).coerceIn(ADJ_W_MIN, ADJ_W_MAX); set(v) = putFlt("adjW", v.coerceIn(ADJ_W_MIN, ADJ_W_MAX))
    /** Добавка к высоте капсулы, pt. */
    var adjH: Float
        get() = flt("adjH", 0f).coerceIn(ADJ_H_MIN, ADJ_H_MAX); set(v) = putFlt("adjH", v.coerceIn(ADJ_H_MIN, ADJ_H_MAX))

    fun resetPosition() {
        if (!ready()) return
        sp.edit().putFloat("offX", 0f).putFloat("offY", 0f).putFloat("adjW", 0f)
            .putFloat("adjH", 0f).putFloat("scale", 1f).apply()
        bump()
    }

    // Источники
    var srcMedia: Boolean
        get() = bool("srcMedia", true); set(v) = putBool("srcMedia", v)
    var srcCalls: Boolean
        get() = bool("srcCalls", true); set(v) = putBool("srcCalls", v)
    var srcTimers: Boolean
        get() = bool("srcTimers", true); set(v) = putBool("srcTimers", v)
    var srcNav: Boolean
        get() = bool("srcNav", true); set(v) = putBool("srcNav", v)
    var srcNotifs: Boolean
        get() = bool("srcNotifs", true); set(v) = putBool("srcNotifs", v)
    var srcSystem: Boolean
        get() = bool("srcSystem", true); set(v) = putBool("srcSystem", v)
    var srcPrivacy: Boolean
        get() = bool("srcPrivacy", true); set(v) = putBool("srcPrivacy", v)

    // Root: по умолчанию ВЫКЛЮЧЕН, приложение полностью работает без него
    var rootMode: Boolean
        get() = bool("rootMode", false); set(v) = putBool("rootMode", v)
    var suppressHeadsUp: Boolean
        get() = bool("suppressHeadsUp", false); set(v) = putBool("suppressHeadsUp", v)
}
