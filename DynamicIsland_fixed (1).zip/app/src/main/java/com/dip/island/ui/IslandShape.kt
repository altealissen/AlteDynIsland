package com.dip.island.ui

import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Прямоугольник со сглаженными углами-суперэллипсами |x/a|^n + |y/a|^n = 1
 * (измерено: n ≈ 2.55–2.77 для капсулы и ≈ 3.1 для expanded), а не дугой окружности.
 */
class IslandShape(private val radius: Float, private val n: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val w = size.width
        val h = size.height
        val r = min(radius, min(w, h) / 2f).coerceAtLeast(0.5f)
        val e = 2f / n
        val steps = 18
        val p = Path()

        fun corner(cx: Float, cy: Float, sx: Float, sy: Float, from: Double, to: Double) {
            for (i in 0..steps) {
                val t = from + (to - from) * i / steps
                val c = cos(t).coerceAtLeast(0.0).pow(e.toDouble()).toFloat()
                val s = sin(t).coerceAtLeast(0.0).pow(e.toDouble()).toFloat()
                p.lineTo(cx + sx * r * c, cy + sy * r * s)
            }
        }

        val q = PI / 2
        p.moveTo(r, 0f)
        p.lineTo(w - r, 0f)
        corner(w - r, r, 1f, -1f, q, 0.0)          // верх -> право
        p.lineTo(w, h - r)
        corner(w - r, h - r, 1f, 1f, 0.0, q)       // право -> низ
        p.lineTo(r, h)
        corner(r, h - r, -1f, 1f, q, 0.0)          // низ -> лево
        p.lineTo(0f, r)
        corner(r, r, -1f, -1f, 0.0, q)             // лево -> верх
        p.close()
        return Outline.Generic(p)
    }
}
