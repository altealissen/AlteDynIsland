package com.dip.island.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.dip.island.core.Prefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Prefs.init(context)
        if (Prefs.enabled && Settings.canDrawOverlays(context)) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, IslandService::class.java))
            } catch (e: Exception) {
            }
        }
    }
}
