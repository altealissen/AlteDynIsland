package com.dip.island.core

import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

/** Арбитраж слотов и расчёт геометрии (чистые функции). */
object Geo {
    private val rank = mapOf(
        Kind.CALL to 1, Kind.NOTIF to 2, Kind.NAV to 3, Kind.RECORDING to 4,
        Kind.TIMER to 5, Kind.MEDIA to 6, Kind.GENERIC to 7
    )

    /** Порядок: закреплённая пользователем, затем ранг, затем свежесть обновления. */
    fun order(items: Collection<IslandItem>, pinned: String?): List<IslandItem> {
        val base = items.sortedWith(
            compareBy<IslandItem> { rank[it.kind] ?: 9 }.thenByDescending { it.updated }
        )
        val p = base.firstOrNull { it.id == pinned } ?: return base
        return listOf(p) + base.filter { it.id != p.id }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Ширина текста в pt. */
    fun textW(text: String, sizePt: Float, env: Env, bold: Boolean = false): Float {
        if (text.isEmpty()) return 0f
        val unit = env.dpPerPt * env.density
        paint.typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.DEFAULT
        paint.textSize = sizePt * unit
        return paint.measureText(text) / unit + 1f
    }

    fun clockTemplate(item: IslandItem, now: Long): String {
        val ms = if (item.countdown) item.clockBase - now else now - item.clockBase
        return if (ms >= 3_600_000L) "0:00:00" else "00:00"
    }

    private fun leadW(i: IslandItem): Float = when (i.kind) {
        Kind.TIMER -> Tok.ICON_TIMER
        Kind.RECORDING -> 0f
        else -> Tok.ART
    }

    private fun trailW(i: IslandItem, env: Env, now: Long): Float = when (i.kind) {
        Kind.MEDIA -> 16.6f
        Kind.TIMER -> if (i.running || i.trail.isEmpty()) textW(clockTemplate(i, now), 15f, env, true)
        else textW(i.trail, 15f, env, true)
        Kind.CALL -> if (i.incoming) 0f else textW(clockTemplate(i, now), 15f, env, true)
        Kind.NAV -> min(textW(i.trail, 15f, env, true), 70f)
        Kind.RECORDING -> 14.5f
        else -> 0f
    }

    private fun ext(w: Float, gap: Float = Tok.CONTENT_GAP) = if (w <= 0f) 0f else Tok.PAD + w + gap

    fun expandedHeight(i: IslandItem): Float = when (i.kind) {
        Kind.MEDIA -> Tok.H_MEDIA
        Kind.TIMER -> Tok.H_TIMER
        Kind.CALL -> Tok.H_CALL
        else -> Tok.H_CARD
    }

    fun compute(
        items: Map<String, IslandItem>,
        alert: IslandAlert?,
        expanded: Boolean,
        pinned: String?,
        env: Env,
        prefShowIdle: Boolean,
        now: Long = System.currentTimeMillis()
    ): Target {
        if (env.hidden) return Target(Mode.HIDDEN)
        val camW = env.camW
        val camH = env.camH
        val ordered = order(items.values, pinned)
        val half = camW / 2
        val main = ordered.firstOrNull()

        if (expanded && main != null) {
            val w = Tok.EXP_W
            return Target(
                Mode.EXPANDED, main, ordered.getOrNull(1), null,
                -w / 2, w / 2, expandedHeight(main), Tok.R_EXP, Tok.N_EXP, 0f, -w / 2, w / 2
            )
        }
        if (alert != null) {
            val leftW = 13.1f + textW(alert.text, 15f, env, true) + Tok.CAM_GAP
            val glyphW = if (alert.batteryLevel >= 0) 33.3f else 21f
            val rightW = 14.06f + glyphW +
                (if (alert.value.isNotEmpty()) textW(alert.value, 15f, env, true) + 7.8f else 0f) + Tok.CAM_GAP
            val w = min(Tok.EXP_W, camW + 2 * max(leftW, rightW))
            return Target(
                Mode.ALERT, main, null, alert, -w / 2, w / 2, camH, camH / 2, Tok.N_PILL,
                0f, -w / 2, w / 2
            )
        }
        if (main == null) {
            return if (prefShowIdle)
                Target(Mode.IDLE, null, null, null, -half, half, camH, camH / 2, Tok.N_PILL, 0f, -half, half)
            else Target(Mode.HIDDEN)
        }
        val second = ordered.getOrNull(1)
        var lead = ext(leadW(main), 1.6f)
        var trail = ext(trailW(main, env, now))
        if (main.kind == Kind.TIMER || main.kind == Kind.CALL) {
            val m = max(lead, trail); lead = m; trail = m
        }
        if (second != null) {
            // Split: остров слева от камеры + круглый пузырь справа (DIP_20 §3)
            val l = max(lead, ext(Tok.ART, 1.6f))
            val bubbleCx = half + Tok.SPLIT_GAP + Tok.BUBBLE / 2
            return Target(
                Mode.SPLIT, main, second, null, -(half + l), half, camH, camH / 2, Tok.N_PILL,
                bubbleCx, -(half + l), bubbleCx + Tok.BUBBLE / 2
            )
        }
        return Target(
            Mode.COMPACT, main, null, null, -(half + lead), half + trail, camH, camH / 2,
            Tok.N_PILL, 0f, -(half + lead), half + trail
        )
    }
}
