package com.dip.island.core

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.telecom.TelecomManager
import android.util.Log
import android.view.KeyEvent

/** Действия без root: Telecom API и медиаклавиши через AudioManager. Root включается как запасной путь. */
object Actions {
    private const val TAG = "DipActions"

    fun answer(ctx: Context) {
        var ok = false
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            ok = true
        } catch (e: Exception) {
            Log.w(TAG, "acceptRingingCall", e)
        }
        if (!ok && Prefs.rootMode) Thread { Root.answerCall() }.start()
    }

    fun end(ctx: Context) {
        var ok = false
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                ok = tm.endCall()
            } catch (e: Exception) {
                Log.w(TAG, "endCall", e)
            }
        }
        if (!ok && Prefs.rootMode) Thread { Root.endCall() }.start()
    }

    fun mediaKey(ctx: Context, code: Int) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (e: Exception) {
            Log.w(TAG, "mediaKey", e)
        }
    }
}
