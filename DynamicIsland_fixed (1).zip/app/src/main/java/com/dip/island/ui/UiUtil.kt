package com.dip.island.ui

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.dip.island.core.C
import com.dip.island.core.Tok
import kotlinx.coroutines.delay

/** dp на один pt iOS с учётом масштаба и ширины экрана. */
val LocalPt = compositionLocalOf { Tok.DP_PER_PT }

@Composable
fun Float.pt(): Dp = (this * LocalPt.current).dp

@Composable
fun Float.ptSp(): TextUnit {
    val u = LocalPt.current
    return with(LocalDensity.current) { (this@ptSp * u).dp.toSp() }
}

fun Long.color(): Color = Color(this)

/** Тикер wall-clock (мс), обновляется каждые [everyMs]. */
@Composable
fun tickWall(everyMs: Long): State<Long> = produceState(System.currentTimeMillis(), everyMs) {
    while (true) {
        value = System.currentTimeMillis()
        delay(everyMs)
    }
}

/** Тикер elapsedRealtime (мс). */
@Composable
fun tickElapsed(everyMs: Long): State<Long> = produceState(SystemClock.elapsedRealtime(), everyMs) {
    while (true) {
        value = SystemClock.elapsedRealtime()
        delay(everyMs)
    }
}

@Composable
fun BitmapBox(bmp: Bitmap?, size: Dp, radius: Dp, fallback: Color = C.BtnGray, modifier: Modifier = Modifier) {
    val img = remember(bmp) { bmp?.asImageBitmap() }
    val shape = RoundedCornerShape(radius)
    Box(modifier.size(size).clip(shape).background(fallback)) {
        if (img != null) {
            Image(img, null, Modifier.size(size), contentScale = ContentScale.Crop)
        }
    }
}
