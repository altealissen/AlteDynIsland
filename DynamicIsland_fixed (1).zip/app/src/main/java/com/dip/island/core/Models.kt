package com.dip.island.core

import android.graphics.Bitmap

enum class Kind { CALL, NOTIF, NAV, RECORDING, TIMER, MEDIA, GENERIC }

enum class Act { PREV, PLAY, PAUSE, NEXT, ACCEPT, DECLINE, HANGUP, STOP, MUTE, OTHER }

class IslandAction(val act: Act, val label: String = "", val run: () -> Unit)

data class IslandItem(
    val id: String,
    val kind: Kind,
    val pkg: String,
    val title: String = "",
    val subtitle: String = "",
    /** Короткий текст справа в compact (дистанция, время). */
    val trail: String = "",
    val cover: Bitmap? = null,
    val appIcon: Bitmap? = null,
    val accent: Long = 0xFFFFFFFF,
    val playing: Boolean = false,
    // Медиа: позиция относится к SystemClock.elapsedRealtime()
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val speed: Float = 1f,
    val stampElapsed: Long = 0,
    // Таймеры и звонки: wall-clock; countdown=true -> clockBase это момент окончания
    val clockBase: Long = 0,
    val countdown: Boolean = false,
    val running: Boolean = true,
    val incoming: Boolean = false,
    val actions: List<IslandAction> = emptyList(),
    val open: (() -> Unit)? = null,
    /** Перемотка на позицию в мс; null, если плеер не поддерживает. */
    val seek: ((Long) -> Unit)? = null,
    val expiresAt: Long = 0,
    val updated: Long = System.currentTimeMillis()
)

enum class Glyph {
    BATTERY, BOLT, BELL, BELL_OFF, HEADPHONES, AIRPLANE, MOON, FLASH, MIC, SAVER, BLUETOOTH, SPEAKER,
    PLAY, PAUSE, NEXT, PREV, PHONE, PHONE_DOWN, CLOSE, STOPWATCH, NAV
}

data class IslandAlert(
    val id: String,
    val text: String,
    val value: String = "",
    val valueColor: Long = 0xFFFFFFFF,
    val glyph: Glyph,
    val glyphColor: Long = 0xFFFFFFFF,
    val batteryLevel: Int = -1
)

enum class Mode { HIDDEN, IDLE, COMPACT, SPLIT, EXPANDED, ALERT }

/** Результат арбитража и геометрии (pt, относительно центра острова по горизонтали). */
data class Target(
    val mode: Mode = Mode.HIDDEN,
    val main: IslandItem? = null,
    val bubble: IslandItem? = null,
    val alert: IslandAlert? = null,
    /** Левый/правый край основной капсулы. */
    val left: Float = -Tok.CAM_W / 2,
    val right: Float = Tok.CAM_W / 2,
    val h: Float = Tok.CAM_H,
    val radius: Float = Tok.CAM_H / 2,
    val n: Float = Tok.N_PILL,
    val bubbleCx: Float = 0f,
    /** Границы всего блока (остров + пузырь) для окна оверлея. */
    val blockLeft: Float = -Tok.CAM_W / 2,
    val blockRight: Float = Tok.CAM_W / 2
)

data class Env(
    val density: Float = 3f,
    val screenWpx: Int = 1080,
    val topPx: Float = 40f,
    val shiftPx: Int = 0,
    val dpPerPt: Float = Tok.DP_PER_PT,
    val keyline: Boolean = true,
    val longPressMs: Long = 350L,
    val rev: Int = 0,
    /** Размеры зоны камеры с учётом ручной подстройки, pt. */
    val camW: Float = Tok.CAM_W,
    val camH: Float = Tok.CAM_H,
    /** Альбомная ориентация: остров скрыт. */
    val hidden: Boolean = false,
    /** Режим настройки положения: показывается контурная капсула. */
    val calib: Boolean = false,
    val fx: Boolean = true,
    /** Постоянная капсула в покое. */
    val idle: Boolean = false
)
