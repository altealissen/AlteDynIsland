package com.dip.island.ui

import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.CircleShape
import com.dip.island.core.C
import com.dip.island.core.Env
import com.dip.island.core.Mode
import com.dip.island.core.Store
import com.dip.island.core.Target
import com.dip.island.core.Tok
import kotlin.math.abs
import kotlin.math.roundToInt

private class Specs(val w: SpringSpec<Float>, val h: SpringSpec<Float>)

private fun specsFor(from: Mode, to: Mode): Specs = when {
    to == Mode.EXPANDED && from != Mode.EXPANDED -> Specs(Tok.EXPAND_W, Tok.EXPAND_H)
    from == Mode.EXPANDED && to != Mode.EXPANDED -> Specs(Tok.COLLAPSE_W, Tok.COLLAPSE_H)
    to == Mode.ALERT && from != Mode.ALERT -> Specs(Tok.ALERT_IN, Tok.ALERT_IN)
    from == Mode.ALERT && to != Mode.ALERT -> Specs(Tok.ALERT_OUT, Tok.ALERT_OUT)
    to == Mode.SPLIT && from != Mode.SPLIT -> Specs(Tok.SPLIT_ISLAND, Tok.SPLIT_ISLAND)
    from == Mode.SPLIT && to != Mode.SPLIT -> Specs(Tok.SPLIT_BACK, Tok.SPLIT_BACK)
    (from == Mode.HIDDEN || from == Mode.IDLE) && to == Mode.COMPACT -> Specs(Tok.APPEAR, Tok.APPEAR)
    from == Mode.COMPACT && (to == Mode.HIDDEN || to == Mode.IDLE) -> Specs(Tok.DISAPPEAR, Tok.DISAPPEAR)
    else -> Specs(Tok.ALERT_IN, Tok.ALERT_IN)
}

/** Состояние, которое переживает рекомпозиции, но само рекомпозицию не вызывает. */
private class Track(var mode: Mode, var specs: Specs, var last: Target)

@Composable
fun IslandRoot() {
    val t by Store.target.collectAsState()
    val env by Store.env.collectAsState()
    val base = LocalViewConfiguration.current
    val lp = env.longPressMs
    val vc = remember(base, lp) {
        object : ViewConfiguration by base {
            override val longPressTimeoutMillis: Long get() = lp
        }
    }
    CompositionLocalProvider(LocalPt provides env.dpPerPt, LocalViewConfiguration provides vc) {
        IslandHost(t, env)
    }
}

@Composable
private fun IslandHost(t: Target, env: Env) {
    val track = remember { Track(t.mode, Specs(Tok.ALERT_IN, Tok.ALERT_IN), t) }
    // Пружины выбираются один раз при смене режима и не «прыгают» при посторонних рекомпозициях
    if (track.mode != t.mode) {
        track.specs = specsFor(track.mode, t.mode)
        track.mode = t.mode
    }
    if (t.mode != Mode.HIDDEN) track.last = t
    val shown = if (t.mode == Mode.HIDDEN) track.last else t
    val sp = track.specs

    // Анимации читаются только в фазах layout/draw (через .value), поэтому покадровой рекомпозиции нет
    val lS = animateFloatAsState(shown.left, sp.w, label = "left")
    val rS = animateFloatAsState(shown.right, sp.w, label = "right")
    val hS = animateFloatAsState(shown.h, sp.h, label = "h")
    val radS = animateFloatAsState(shown.radius, sp.h, label = "radius")
    val nS = animateFloatAsState(shown.n, sp.w, label = "n")
    val isSplit = shown.mode == Mode.SPLIT && t.mode == Mode.SPLIT
    val bxS = animateFloatAsState(if (isSplit) shown.bubbleCx else env.camW / 2, Tok.BUBBLE_SPR, label = "bx")
    val bScaleS = animateFloatAsState(if (isSplit) 1f else 0f, Tok.BUBBLE_SPR, label = "bscale")
    val alphaS = animateFloatAsState(
        if (t.mode == Mode.HIDDEN) 0f else 1f,
        tween(if (t.mode == Mode.HIDDEN) 120 else 30, if (t.mode == Mode.HIDDEN) 300 else 0), label = "alpha"
    )

    val cur by rememberUpdatedState(t)
    var pressed by remember { mutableStateOf(false) }
    val pressS = animateFloatAsState(
        if (pressed && (t.mode == Mode.COMPACT || t.mode == Mode.SPLIT)) Tok.LONG_PRESS_INFLATE else 1f,
        Tok.PRESS, label = "press"
    )

    val unit = env.dpPerPt * env.density          // пикселей в одном pt
    val topPx = env.topPx.roundToInt()
    val showKeyline = (env.keyline && t.mode == Mode.EXPANDED) || (env.calib && t.mode == Mode.IDLE)
    val camHPx = (env.camH * unit).roundToInt().coerceAtLeast(1)
    val bubblePx = (Tok.BUBBLE * unit).roundToInt().coerceAtLeast(1)
    val bubbleVisible by remember { derivedStateOf { bScaleS.value > 0.01f } }

    Box(Modifier.fillMaxSize().graphicsLayer { this.alpha = alphaS.value }) {
        // Основная капсула
        Box(
            Modifier.align(Alignment.TopCenter)
                .offset { IntOffset(((lS.value + rS.value) / 2f * unit).roundToInt(), topPx) }
                .layout { measurable, _ ->
                    val w = ((rS.value - lS.value) * unit).roundToInt().coerceAtLeast(1)
                    val h = (hS.value * unit).roundToInt().coerceAtLeast(1)
                    val placeable = measurable.measure(Constraints.fixed(w, h))
                    layout(w, h) { placeable.place(0, 0) }
                }
                .graphicsLayer {
                    val s = pressS.value
                    scaleX = s; scaleY = s; transformOrigin = TransformOrigin(0.5f, 0f)
                    shape = IslandShape((radS.value * unit).coerceAtLeast(0.5f), nS.value)
                    clip = true
                }
                .drawBehind {
                    drawRect(C.Black)
                    if (showKeyline) {
                        val outline = IslandShape((radS.value * unit).coerceAtLeast(0.5f), nS.value)
                            .createOutline(size, layoutDirection, this)
                        drawOutline(outline, Color.White.copy(alpha = if (env.calib) 0.55f else 0.14f), style = Stroke(width = 1.dp.toPx()))
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            if (cur.mode == Mode.COMPACT || cur.mode == Mode.SPLIT) pressed = true
                            try { tryAwaitRelease() } finally { pressed = false }
                        },
                        onLongPress = {
                            if ((cur.mode == Mode.COMPACT || cur.mode == Mode.SPLIT) && cur.main != null) {
                                Store.setExpanded(true)
                            }
                        },
                        onTap = {
                            val c = cur
                            if (c.mode == Mode.COMPACT || c.mode == Mode.SPLIT || c.mode == Mode.EXPANDED) {
                                try { c.main?.open?.invoke() } catch (e: Exception) { }
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    var acc = 0f
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = {
                            if (acc < -24.dp.toPx() && cur.mode == Mode.EXPANDED) Store.setExpanded(false)
                        },
                        onDragCancel = { },
                        onVerticalDrag = { _, dy -> acc += dy }
                    )
                }
                .pointerInput(Unit) {
                    var acc = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragEnd = {
                            val m = cur.mode
                            if (abs(acc) > 40.dp.toPx() && (m == Mode.COMPACT || m == Mode.SPLIT)) {
                                Store.cycle()
                            }
                        },
                        onDragCancel = { },
                        onHorizontalDrag = { _, dx -> acc += dx }
                    )
                }
        ) {
            IslandContent(shown, env.fx)
        }

        // Отделённый пузырь (split)
        val bub = shown.bubble
        if (bub != null && bubbleVisible) {
            val src = remember { MutableInteractionSource() }
            Box(
                Modifier.align(Alignment.TopCenter)
                    .offset { IntOffset((bxS.value * unit).roundToInt(), topPx) }
                    .layout { measurable, _ ->
                        val placeable = measurable.measure(Constraints.fixed(bubblePx, camHPx))
                        layout(bubblePx, camHPx) { placeable.place(0, 0) }
                    }
                    .graphicsLayer {
                        val s = bScaleS.value
                        scaleX = s; scaleY = s
                        shape = CircleShape
                        clip = true
                    }
                    .background(C.Black)
                    .clickable(interactionSource = src, indication = null) { Store.select(bub.id) },
                contentAlignment = Alignment.Center
            ) { LeadIcon(bub) }
        }
    }
}

@Composable
private fun IslandContent(shown: Target, fx: Boolean) {
    val key = when (shown.mode) {
        Mode.EXPANDED -> "x:" + shown.main?.id
        Mode.ALERT -> "a:" + shown.alert?.id
        Mode.COMPACT, Mode.SPLIT -> "c:" + shown.main?.id
        else -> "i"
    }
    val snaps = remember { HashMap<String, Target>() }
    snaps[key] = shown
    if (snaps.size > 8) snaps.keys.filter { it != key }.take(snaps.size - 8).forEach { snaps.remove(it) }
    val blurOk = fx && Build.VERSION.SDK_INT >= 31
    AnimatedContent(
        targetState = key,
        modifier = Modifier.fillMaxSize(),
        transitionSpec = {
            fadeIn(tween(Tok.CONTENT_IN_MS, Tok.CONTENT_IN_DELAY)) togetherWith
                fadeOut(tween(Tok.CONTENT_OUT_MS, Tok.CONTENT_OUT_DELAY))
        },
        contentAlignment = Alignment.TopStart,
        label = "content"
    ) { k ->
        val tt = snaps[k] ?: shown
        val p by transition.animateFloat(
            transitionSpec = { tween(Tok.CONTENT_IN_MS, Tok.CONTENT_IN_DELAY) }, label = "appear"
        ) { st -> if (st == EnterExitState.PreEnter) 1f else 0f }
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer {
                    val s = 1f - (1f - Tok.CONTENT_SCALE) * p
                    scaleX = s; scaleY = s; transformOrigin = TransformOrigin.Center
                }
                .then(if (blurOk) Modifier.blur((Tok.CONTENT_BLUR * p).dp) else Modifier)
        ) {
            when (tt.mode) {
                Mode.EXPANDED -> tt.main?.let { ExpandedContent(it) }
                Mode.ALERT -> tt.alert?.let { AlertContent(it) }
                Mode.COMPACT, Mode.SPLIT -> CompactContent(tt)
                else -> Unit
            }
        }
    }
}
